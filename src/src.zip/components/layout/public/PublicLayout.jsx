// src/components/layout/public/PublicLayout.jsx
import React, { useState, useEffect, createContext } from 'react';
import { Outlet } from 'react-router-dom';
import useAuth from '../../../hooks/UseAuth';
import Header from './Header';
import Footer from './Footer';
import AuthModal from './AuthModal';
import { EditProvider, useEdit } from '../../../context/EditContext';
import EditModal from '../../editing/EditModal';

// Context para el modo editor
export const AdminModeContext = createContext({
    isAdminMode: false,
    setIsAdminMode: () => { },
    isAdminUser: false
});

const PublicLayout = () => {
    const { auth, loading } = useAuth();
    const [isAuthOpen, setIsAuthOpen] = useState(false);
    const [isAdminMode, setIsAdminMode] = useState(false);

    // Solo roles permitidos pueden activar modo admin
    const isAdminUser = ['editor', 'admin', 'superadmin'].includes(auth?.role?.role_name);

    // Resetea modo admin si el usuario pierde permisos
    useEffect(() => {
        if (!isAdminUser) setIsAdminMode(false);
    }, [isAdminUser]);

    // Añade/quita clase al body cuando cambie isAdminMode
    useEffect(() => {
        document.body.classList.toggle('admin-mode', isAdminMode);
    }, [isAdminMode]);

    if (loading) return <p>Cargando…</p>;

    // Handlers de auth
    const handleLogin = ({ email, password }) => {
        console.log('Login:', email, password);
        setIsAuthOpen(false);
    };
    const handleRegister = ({ name, email, password, confirm }) => {
        console.log('Register:', { name, email, password, confirm });
        setIsAuthOpen(false);
    };
    const handleRecover = ({ email }) => {
        console.log('Recover:', email);
        setIsAuthOpen(false);
    };

    return (
        <EditProvider>

            <AdminModeContext.Provider value={{ isAdminMode, setIsAdminMode, isAdminUser }}>
                <>
                    {/* Header con toggle condicional */}
                    <Header
                        onOpenAuth={() => setIsAuthOpen(true)}
                        onToggleAdmin={isAdminUser ? () => setIsAdminMode(m => !m) : undefined}
                        isAdminMode={isAdminMode}
                        isAdminUser={isAdminUser}
                    />

                    {/* Modal de autenticación */}
                    <AuthModal
                        isOpen={isAuthOpen}
                        onClose={() => setIsAuthOpen(false)}
                        onLogin={handleLogin}
                        onRegister={handleRegister}
                        onRecover={handleRecover}
                    />

                    {/* Contenido de la página */}
                    <main>
                        <Outlet />
                    </main>

                    {/* Footer */}
                    <Footer />
                    <EditModalWrapper />

                </>
            </AdminModeContext.Provider>
        </EditProvider>

    );
};

// Componente que consume EditContext y muestra EditModal si abierto
function EditModalWrapper() {
    const { editState, closeEditModal, handleSave } = useEdit();
    return (
        <EditModal
            isOpen={editState.isOpen}
            type={editState.type}
            values={editState.values}
            options={editState.options}
            onClose={closeEditModal}
            onSave={handleSave}
        />
    );
}

export default PublicLayout;
