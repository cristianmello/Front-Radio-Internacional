import React, { useState, useEffect, useRef } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import ConfirmDeleteModal from "../../../editing/modal/ConfirmDeleteModal";
import { useEditable } from "../../../../hooks/useEditable";

// ---------- Más Leídos ----------
const defaultItems = [
    {
        id: "pp1",
        imageUrl: "https://source.unsplash.com/random/100x100/?food",
        alt: "Gastronomía",
        title: "La cocina tradicional es declarada patrimonio inmaterial",
        date: "Hace 4 días",
        linkUrl: "/articulo/201",
    },
    {
        id: "pp2",
        imageUrl: "https://source.unsplash.com/random/100x100/?travel",
        alt: "Viajes",
        title: "Destinos turísticos menos conocidos ganan popularidad",
        date: "Hace 1 semana",
        linkUrl: "/articulo/202",
    },
    {
        id: "pp3",
        imageUrl: "https://source.unsplash.com/random/100x100/?fashion",
        alt: "Moda",
        title: "La moda sostenible domina las pasarelas esta temporada",
        date: "Hace 2 días",
        linkUrl: "/articulo/203",
    },
];

export default function PopularPosts({ isAdminMode, initialItems, onUpdate, onDelete }) {
    const [items, setItems] = useState(initialItems.length ? initialItems : defaultItems);
    const [toDeleteId, setToDeleteId] = useState(null);

    useEffect(() => {
        if (initialItems.length) setItems(initialItems);
    }, [initialItems]);

    const handleUpdate = (id, fields) => {
        setItems(prev => prev.map(i => i.id === id ? { ...i, ...fields } : i));
        onUpdate?.(id, fields);
    };
    const handleConfirmDelete = () => {
        setItems(prev => prev.filter(i => i.id !== toDeleteId));
        onDelete?.(toDeleteId);
        setToDeleteId(null);
    };

    return (
        <div className="widget popular-posts">
            <h3>Más Leídos</h3>
            <ul>
                {items.map(post => (
                    <li key={post.id} className={isAdminMode ? "editable-container post" : "post"}>
                        {isAdminMode && (
                            <button className="delete-item-btn" onClick={() => setToDeleteId(post.id)} aria-label="Eliminar post">
                                🗑
                            </button>
                        )}
                        <EditableImage
                            isAdminMode={isAdminMode}
                            src={post.imageUrl}
                            alt={post.alt}
                            onSave={vals => handleUpdate(post.id, { imageUrl: vals.src, alt: vals.alt })}
                            presets={["food", "travel", "fashion", "popular-post"]}
                        />
                        <EditableText
                            isAdminMode={isAdminMode}
                            tag="h5"
                            children={post.title}
                            onSave={html => handleUpdate(post.id, { title: html })}
                        />
                        <EditableText
                            isAdminMode={isAdminMode}
                            tag="span"
                            className="date"
                            children={post.date}
                            onSave={text => handleUpdate(post.id, { date: text })}
                            type="date"
                            quickDates={["Ahora", "Hace 1 día", "Hace 2 días", "Hace 1 semana"]}
                        />
                    </li>
                ))}
            </ul>
            <ConfirmDeleteModal
                isOpen={!!toDeleteId}
                type="post"
                onCancel={() => setToDeleteId(null)}
                onConfirm={handleConfirmDelete}
            />
        </div>
    );
}

PopularPosts.propTypes = {
    isAdminMode: PropTypes.bool,
    initialItems: PropTypes.array,
    onUpdate: PropTypes.func,
    onDelete: PropTypes.func,
};

// Auxiliares
function EditableImage({ isAdminMode, src, alt, onSave, presets }) {
    const ref = useRef();
    useEditable(ref, "image", () => ({ src, alt }), () => ({ presets }), onSave, { field: "image" });
    return (
        <div ref={ref} className={isAdminMode ? "editable post-image" : "post-image"} style={{ cursor: isAdminMode ? "pointer" : "default" }}>
            <img src={src} alt={alt} />
        </div>
    );
}

function EditableText({ isAdminMode, tag, children, onSave, type = "text", quickDates = [], className = "" }) {
    const ref = useRef();
    useEditable(
        ref,
        type,
        () => type === "text" ? ({ html: children }) : ({ text: children }),
        () => ({ label: type === "date" ? "Fecha:" : "", quickDates }),
        vals => onSave(type === "text" ? vals.html : vals.text),
        { field: type }
    );
    const Tag = tag;
    return (
        <Tag ref={ref} className={isAdminMode ? `editable ${className}` : className} style={{ cursor: isAdminMode ? "pointer" : "default" }}>
            {children}
        </Tag>
    );
}
