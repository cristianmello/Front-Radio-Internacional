// src/components/layout/public/home/MainContent.jsx
import React, {
  useState,
  useRef,
  useContext,
  useEffect,
  useCallback
} from "react";
import PropTypes from "prop-types";
import NewsItem from "./NewsItem";
import Sidebar from "./Sidebar";
import "../../../../assets/css/MainContent.css";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";
import ConfirmDeleteModal from "../../../editing/modal/ConfirmDeleteModal";

// 1. Datos por defecto para Destacados (fuera del componente)
const defaultNews = [
  {
    articleId: "9",
    category: "Medio Ambiente",
    title: "Récord de temperaturas preocupa a científicos climáticos",
    excerpt:
      "Los últimos datos confirman la tendencia al calentamiento global acelerado y sus consecuencias para ecosistemas vulnerables en todo el planeta.",
    author: "Carlos Martínez",
    date: "Hace 5 horas",
    imageUrl: "https://source.unsplash.com/random/800x500/?environment"
  },
  {
    articleId: "10",
    category: "Educación",
    title: "Reforma educativa incluirá programación como asignatura obligatoria",
    excerpt:
      "El ministerio anuncia cambios curriculares para preparar a los estudiantes para el futuro digital desde edades tempranas.",
    author: "Ana López",
    date: "Hace 1 día",
    imageUrl: "https://source.unsplash.com/random/800x500/?education"
  },
  {
    articleId: "11",
    category: "Negocios",
    title: "Startup local recibe financiación millonaria para expandirse globalmente",
    excerpt:
      "La compañía de tecnología verde atrajo a inversores internacionales con su innovador modelo de negocio sostenible.",
    author: "Roberto Sánchez",
    date: "Hace 3 días",
    imageUrl: "https://source.unsplash.com/random/800x500/?business"
  }
];

const MainContent = ({
  initialNews = [],
  onUpdateNewsItem,
  onDeleteNewsItem,
  onUpdateHeader
}) => {
  const { isAdminMode } = useContext(AdminModeContext);

  // 2. Encabezado editable
  const [headerText, setHeaderText] = useState("Destacados");
  const headerRef = useRef();

  const getHeaderValues = useCallback(() => ({ html: headerText }), [headerText]);
  const getHeaderOptions = useCallback(() => ({}), []);

  const handleHeaderSave = useCallback(
    (vals) => {
      setHeaderText(vals.html);
      onUpdateHeader?.(vals.html);
    },
    [onUpdateHeader]
  );

  useEditable(
    headerRef,
    "text",
    getHeaderValues,
    getHeaderOptions,
    handleHeaderSave,
    { field: "header" }
  );

  // 3. Función para normalizar incoming news
  const mapItems = useCallback(
    (items) =>
      items.map((item) => ({
        articleId: String(item.articleId),
        category: item.category || "",
        title: item.title || "",
        excerpt: item.excerpt || "",
        author: item.author || "",
        date: item.date || "",
        imageUrl: item.imageUrl || ""
      })),
    []
  );

  // 4. Estado de lista de noticias
  const [newsList, setNewsList] = useState(
    initialNews.length ? mapItems(initialNews) : defaultNews
  );

  // 5. Sincronizar si cambian las props initialNews
  useEffect(() => {
    if (initialNews.length) {
      setNewsList(mapItems(initialNews));
    }
  }, [initialNews, mapItems]);

  // 6. Actualizar un ítem
  const handleUpdateItem = useCallback(
    (articleId, updatedFields) => {
      setNewsList((prev) =>
        prev.map((item) =>
          item.articleId === String(articleId)
            ? { ...item, ...updatedFields }
            : item
        )
      );
      onUpdateNewsItem?.(articleId, updatedFields);
    },
    [onUpdateNewsItem]
  );

  // 7. Modo borrado con confirmación
  const [toDelete, setToDelete] = useState(null);
  const handleConfirmDelete = useCallback(() => {
    setNewsList((prev) => prev.filter((i) => i.articleId !== toDelete));
    onDeleteNewsItem?.(toDelete);
    setToDelete(null);
  }, [onDeleteNewsItem, toDelete]);

  return (
    <div className="news-layout">
      {/* ===== Destacados ===== */}
      <section className="main-content">
        <div className="section-header">
          <h2
            ref={headerRef}
            className={isAdminMode ? "editable" : ""}
            {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
          >
            {headerText}
          </h2>
        </div>
        <div className="news-list">
          {newsList.map((item) => (
            <NewsItem
              key={item.articleId}
              {...item}
              onUpdate={handleUpdateItem}
              onDelete={() => setToDelete(item.articleId)}
            />
          ))}
        </div>
      </section>

      {/* ===== Sidebar ===== */}
      <Sidebar />

      {/* ===== Modal de borrado ===== */}
      <ConfirmDeleteModal
        isOpen={!!toDelete}
        type="noticia"
        onCancel={() => setToDelete(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
};

MainContent.propTypes = {
  initialNews: PropTypes.arrayOf(
    PropTypes.shape({
      articleId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      category: PropTypes.string,
      title: PropTypes.string,
      excerpt: PropTypes.string,
      author: PropTypes.string,
      date: PropTypes.string,
      imageUrl: PropTypes.string
    })
  ),
  onUpdateNewsItem: PropTypes.func,
  onDeleteNewsItem: PropTypes.func,
  onUpdateHeader: PropTypes.func
};

export default MainContent;
