// src/components/layout/public/home/NewsItem.jsx
import React, { useRef, useState, useContext, useCallback } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";
import "./NewsItem.css"; // Mueve ahí los estilos de .delete-button

const NewsItem = ({
    category,
    title,
    excerpt,
    author,
    date,
    imageUrl,
    articleId,
    onUpdate,
    onDelete
}) => {
    const { isAdminMode } = useContext(AdminModeContext);

    // Estado local de campos
    const [localCategory, setLocalCategory] = useState(category);
    const [localTitle, setLocalTitle] = useState(title);
    const [localExcerpt, setLocalExcerpt] = useState(excerpt);
    const [localAuthor, setLocalAuthor] = useState(author);
    const [localDate, setLocalDate] = useState(date);
    const [localImageUrl, setLocalImageUrl] = useState(imageUrl);

    // Refs para edición
    const categoryRef = useRef();
    const titleRef = useRef();
    const excerptRef = useRef();
    const authorRef = useRef();
    const dateRef = useRef();
    const imageRef = useRef();

    // Persistir cambios
    const handleSaveField = useCallback(
        (newValues, meta) => {
            const { field } = meta;
            const updated = {};

            switch (field) {
                case "category":
                    setLocalCategory(newValues.text);
                    updated.category = newValues.text;
                    break;
                case "title":
                    setLocalTitle(newValues.html);
                    updated.title = newValues.html;
                    break;
                case "excerpt":
                    setLocalExcerpt(newValues.html);
                    updated.excerpt = newValues.html;
                    break;
                case "author":
                    setLocalAuthor(newValues.text);
                    updated.author = newValues.text;
                    break;
                case "date":
                    setLocalDate(newValues.text);
                    updated.date = newValues.text;
                    break;
                case "image":
                    setLocalImageUrl(newValues.src);
                    updated.imageUrl = newValues.src;
                    break;
                default:
                    break;
            }

            if (onUpdate && Object.keys(updated).length) {
                onUpdate(articleId, updated);
            }
        },
        [articleId, onUpdate]
    );

    // Hooks de edición
    useEditable(
        categoryRef,
        "category",
        () => ({ text: localCategory }),
        () => ({
            categories: [
                "Política",
                "Economía",
                "Tecnología",
                "Deportes",
                "Entretenimiento",
                "Ciencia",
                "Salud",
                "Internacional",
                "Cultura",
                "Medio Ambiente",
                "Educación"
            ]
        }),
        handleSaveField,
        { field: "category" }
    );

    useEditable(
        titleRef,
        "text",
        () => ({ html: localTitle }),
        () => ({}),
        handleSaveField,
        { field: "title" }
    );

    useEditable(
        excerptRef,
        "text",
        () => ({ html: localExcerpt }),
        () => ({}),
        handleSaveField,
        { field: "excerpt" }
    );

    useEditable(
        authorRef,
        "text",
        () => ({ text: localAuthor }),
        () => ({}),
        handleSaveField,
        { field: "author" }
    );

    useEditable(
        dateRef,
        "date",
        () => ({ text: localDate }),
        () => ({
            label: "Fecha:",
            quickDates: [
                "Ahora",
                "Hace 1 hora",
                "Hace 5 horas",
                "Ayer",
                "Hace 2 días",
                "Hace 1 semana"
            ]
        }),
        handleSaveField,
        { field: "date" }
    );

    useEditable(
        imageRef,
        "image",
        () => ({ src: localImageUrl, alt: localTitle }),
        () => ({
            presets: [
                "news",
                "politics",
                "technology",
                "economy",
                "sports",
                "entertainment",
                "science"
            ]
        }),
        handleSaveField,
        { field: "image" }
    );

    return (
        <article className="news-item">
            <div className="news-item-image" ref={imageRef}>
                <img src={localImageUrl} alt={localTitle} />
            </div>
            <div className="news-item-content">
                <span className="category" ref={categoryRef}>
                    {localCategory}
                </span>
                <h3 ref={titleRef}>{localTitle}</h3>
                <p className="excerpt" ref={excerptRef}>
                    {localExcerpt}
                </p>
                <div className="article-meta">
                    <span className="author" ref={authorRef}>
                        Por {localAuthor}
                    </span>
                    <span className="date" ref={dateRef}>
                        {localDate}
                    </span>
                </div>
                <Link to={`/articulo/${articleId}`} className="read-more">
                    Leer más
                </Link>

                {isAdminMode && (
                    <button
                        className="delete-button"
                        onClick={() => onDelete?.(articleId)}
                        aria-label={`Eliminar artículo ${localTitle}`}
                    >
                        Eliminar
                    </button>
                )}
            </div>
        </article>
    );
};

NewsItem.propTypes = {
    category: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    excerpt: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    imageUrl: PropTypes.string.isRequired,
    articleId: PropTypes.oneOfType([PropTypes.string, PropTypes.number])
        .isRequired,
    onUpdate: PropTypes.func,
    onDelete: PropTypes.func
};

export default NewsItem;
