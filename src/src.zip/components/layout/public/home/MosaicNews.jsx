// src/components/layout/public/home/MosaicNews.jsx
import React, {
    useState,
    useEffect,
    useCallback,
    useRef,
    useContext
} from "react";
import PropTypes from "prop-types";
import MosaicItem from "./MosaicItem";
import "../../../../assets/css/MosaicNews.css";
import { AdminModeContext } from "../PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";

// 1. Datos por defecto, fuera del componente
const defaultItems = [
    {
        id: "m1",
        size: "large",
        imageUrl: "https://source.unsplash.com/random/800x600/?breaking-news",
        alt: "Noticia destacada",
        category: "Internacional",
        title:
            "Cumbre internacional aborda crisis migratoria global con nuevos acuerdos",
        excerpt:
            "Países desarrollados y en desarrollo alcanzan consenso histórico sobre responsabilidad compartida.",
        linkUrl: "/articulo/100",
    },
    {
        id: "m2",
        size: "",
        imageUrl: "https://source.unsplash.com/random/400x300/?finance",
        alt: "Finanzas",
        category: "Finanzas",
        title: "Criptomonedas recuperan terreno tras regulación",
        // no excerpt en este item
        linkUrl: "/articulo/101",
    },
    {
        id: "m3",
        size: "",
        imageUrl: "https://source.unsplash.com/random/400x300/?innovation",
        alt: "Innovación",
        category: "Innovación",
        title: "Vehículos autónomos comienzan pruebas en zonas urbanas",
        linkUrl: "/articulo/102",
    },
    {
        id: "m4",
        size: "vertical",
        imageUrl: "https://source.unsplash.com/random/400x600/?culture",
        alt: "Cultura",
        category: "Cultura",
        title: "Exposición de arte digital rompe récords de asistencia",
        excerpt:
            "La fusión de tecnología y arte tradicional atrae a nuevas audiencias.",
        linkUrl: "/articulo/103",
    },
    {
        id: "m5",
        size: "",
        imageUrl: "https://source.unsplash.com/random/400x300/?fashion",
        alt: "Moda",
        category: "Moda",
        title:
            "Diseñadores emergentes destacan con materiales sostenibles",
        linkUrl: "/articulo/104",
    },
    {
        id: "m6",
        size: "",
        imageUrl: "https://source.unsplash.com/random/400x300/?gastronomy",
        alt: "Gastronomía",
        category: "Gastronomía",
        title:
            "Ingredientes ancestrales revolucionan la alta cocina",
        linkUrl: "/articulo/105",
    },
];

const MosaicNews = ({ initialItems = [], onUpdateItem }) => {
    const { isAdminMode } = useContext(AdminModeContext);

    // 2. Editable: encabezado "Panorama Noticioso"
    const [headerText, setHeaderText] = useState("Panorama Noticioso");
    const headerRef = useRef();

    const getHeaderValues = useCallback(() => ({ html: headerText }), [headerText]);
    const getHeaderOptions = useCallback(() => ({}), []);

    const handleHeaderSave = useCallback(
        ({ html }) => {
            setHeaderText(html);
            // aquí podrías llamar a un onUpdateHeader si lo necesitas
        },
        []
    );

    useEditable(
        headerRef,
        "text",
        getHeaderValues,
        getHeaderOptions,
        handleHeaderSave,
        { field: "mosaicHeader" }
    );

    // 3. Estado de items
    const [items, setItems] = useState(
        Array.isArray(initialItems) && initialItems.length > 0
            ? initialItems
            : defaultItems
    );

    // 4. Sincronizar props→estado si cambian initialItems
    useEffect(() => {
        if (Array.isArray(initialItems) && initialItems.length > 0) {
            setItems(initialItems);
        }
    }, [initialItems]);

    // 5. Handler para actualizar un item concreto
    const handleUpdate = useCallback(
        (id, updatedFields) => {
            setItems((prev) =>
                prev.map((it) => (it.id === id ? { ...it, ...updatedFields } : it))
            );
            onUpdateItem?.(id, updatedFields);
        },
        [onUpdateItem]
    );

    return (
        <section className="mosaic-news">
            <div className="section-header">
                <h2
                    ref={headerRef}
                    className={isAdminMode ? "editable" : ""}
                    {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
                >
                    {headerText}
                </h2>
            </div>
            <div className="mosaic-container">
                {items.map((item) => (
                    <MosaicItem
                        key={item.id}
                        item={item}
                        onUpdate={handleUpdate}
                    />
                ))}
            </div>
        </section>
    );
};

MosaicNews.propTypes = {
    initialItems: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            size: PropTypes.string,
            imageUrl: PropTypes.string.isRequired,
            alt: PropTypes.string,
            category: PropTypes.string.isRequired,
            title: PropTypes.string.isRequired,
            excerpt: PropTypes.string,
            linkUrl: PropTypes.string.isRequired
        })
    ),
    onUpdateItem: PropTypes.func
};

export default MosaicNews;
