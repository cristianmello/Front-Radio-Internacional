// src/components/layout/public/home/StoryItem.jsx
import React, { useState, useRef, useContext } from "react";
import { Link } from "react-router-dom";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";

const StoryItem = ({ story, onUpdate }) => {
    /**
     * story: { id, imageUrl, alt, category, title, excerpt, linkUrl }
     * onUpdate: función (id, updatedFields)
     */
    const { id, linkUrl: initialLinkUrl } = story;
    const { isAdminMode } = useContext(AdminModeContext);

    // Estados locales
    const [localImageUrl, setLocalImageUrl] = useState(story.imageUrl);
    const [localAlt, setLocalAlt] = useState(story.alt || "");
    const [localCategory, setLocalCategory] = useState(story.category);
    const [localTitle, setLocalTitle] = useState(story.title);
    const [localExcerpt, setLocalExcerpt] = useState(story.excerpt);
    const [localLinkUrl, setLocalLinkUrl] = useState(
        story.linkUrl || "#"
    );

    // Refs para elementos editables
    const imgRef = useRef();
    const altRef = useRef(); // opcional si se quiere editar alt por separado
    const categoryRef = useRef();
    const titleRef = useRef();
    const excerptRef = useRef();
    const linkRef = useRef();

    // Callback que se pasa a useEditable
    const handleSaveField = (field, newValues) => {
        const updated = {};
        switch (field) {
            case "image":
                setLocalImageUrl(newValues.src);
                setLocalAlt(newValues.alt || "");
                updated.imageUrl = newValues.src;
                updated.alt = newValues.alt;
                break;
            case "alt":
                setLocalAlt(newValues.text || "");
                updated.alt = newValues.text;
                break;
            case "category":
                setLocalCategory(newValues.text);
                updated.category = newValues.text;
                break;
            case "title":
                setLocalTitle(newValues.html);
                updated.title = newValues.html;
                break;
            case "excerpt":
                setLocalExcerpt(newValues.html);
                updated.excerpt = newValues.html;
                break;
            case "link":
                setLocalLinkUrl(newValues.href);
                updated.linkUrl = newValues.href;
                break;
            default:
                break;
        }
        if (Object.keys(updated).length && typeof onUpdate === "function") {
            onUpdate(id, updated);
        }
    };

    // Registramos cada parte editable en modo admin con useEditable(ref, type, getValues, getOptions, onSave, meta)
    // 1) Imagen: podemos editar src y alt en un único modal tipo 'image'
    useEditable(
        imgRef,
        "image",
        () => ({ src: localImageUrl, alt: localAlt }),
        () => ({ presets: ["technology", "economy", "sports", "news"] }),
        (vals) => handleSaveField("image", vals),
        { field: "image" }
    );

    // (Opcional) Si queremos punto separado para editar alt:
    // useEditable(
    //   altRef,
    //   "text",
    //   () => ({ html: localAlt }),
    //   () => ({}),
    //   (vals) => handleSaveField("alt", { text: vals.html }),
    //   { field: "alt" }
    // );

    // Categoría
    useEditable(
        categoryRef,
        "category",
        () => ({ text: localCategory }),
        () => ({
            categories: [
                "Política",
                "Economía",
                "Tecnología",
                "Deportes",
                "Cultura",
                "Ciencia",
            ],
        }),
        (vals) => handleSaveField("category", vals),
        { field: "category" }
    );

    // Título
    useEditable(
        titleRef,
        "text",
        () => ({ html: localTitle }),
        () => ({}),
        (vals) => handleSaveField("title", vals),
        { field: "title" }
    );

    // Extracto
    useEditable(
        excerptRef,
        "text",
        () => ({ html: localExcerpt }),
        () => ({}),
        (vals) => handleSaveField("excerpt", vals),
        { field: "excerpt" }
    );

    // Link para “Leer más”
    useEditable(
        linkRef,
        "link",
        () => ({ href: localLinkUrl }),
        () => ({ label: "URL del artículo" }),
        (vals) => handleSaveField("link", vals),
        { field: "link" }
    );

    return (
        <div className="story">
            <div className="story-image">
                {/* 
          Ponemos ref en el contenedor de la imagen o directamente en el <img>;
          aquí ponemos ref en un div que envuelve el img para escuchar clicks.
        */}
                <div ref={imgRef} style={{ cursor: isAdminMode ? "pointer" : "default" }}>
                    <img src={localImageUrl} alt={localAlt} />
                </div>
            </div>
            <div className="story-content">
                <span
                    className="category"
                    ref={categoryRef}
                    style={{ cursor: isAdminMode ? "pointer" : "default" }}
                >
                    {localCategory}
                </span>
                <h4
                    ref={titleRef}
                    style={{ cursor: isAdminMode ? "pointer" : "default" }}
                >
                    {localTitle}
                </h4>
                <p
                    className="excerpt"
                    ref={excerptRef}
                    style={{ cursor: isAdminMode ? "pointer" : "default" }}
                >
                    {localExcerpt}
                </p>
                <Link
                    to={localLinkUrl || "#"}
                    className="read-more"
                    ref={linkRef}
                    style={{ cursor: isAdminMode ? "pointer" : "pointer" }}
                    onClick={(e) => {
                        // Si la URL es '#', evitar navegación inútil
                        if (isAdminMode && (!localLinkUrl || localLinkUrl === "#")) {
                            e.preventDefault();
                        }
                    }}
                >
                    Leer más
                </Link>
            </div>
        </div>
    );
};

export default StoryItem;
