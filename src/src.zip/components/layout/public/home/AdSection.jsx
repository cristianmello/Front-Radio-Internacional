// src/components/layout/public/home/AdSection.jsx
import React, { useRef, useState } from "react";
import { useEditable } from '../../../../hooks/useEditable';
import "../../../../assets/css/AdSection.css";

const AdSection = ({ initialImageUrl, initialAlt = 'Anuncio', initialLinkUrl = '#' }) => {
    const [localImageUrl, setLocalImageUrl] = useState(initialImageUrl || 'https://source.unsplash.com/random/970x250/?advertisement');
    const [localAlt, setLocalAlt] = useState(initialAlt);
    const [localLinkUrl, setLocalLinkUrl] = useState(initialLinkUrl);
    const [localDisclaimer, setLocalDisclaimer] = useState('Publicidad');

    const imgRef = useRef();
    const linkRef = useRef();
    const disclaimerRef = useRef();

    const handleSaveField = (newValues, meta) => {
        const { field } = meta;
        switch (field) {
            case 'image':
                setLocalImageUrl(newValues.src);
                break;
            case 'alt':
                setLocalAlt(newValues.alt || newValues.text || '');
                break;
            case 'link':
                setLocalLinkUrl(newValues.href);
                break;
            case 'disclaimer':
                setLocalDisclaimer(newValues.html || newValues.text || '');
                break;
            default:
                break;
        }
    };

    // Editable: imagen
    useEditable(
        imgRef,
        'image',
        () => ({ src: localImageUrl, alt: localAlt }),
        () => ({ presets: ['advertisement', 'banner', 'promo'] }),
        handleSaveField,
        { field: 'image' }
    );
    // Editable: alt text
    // Note: could combine with image, but if separate needed
    // Editable: link URL
    useEditable(
        linkRef,
        'link',
        () => ({ href: localLinkUrl }),
        () => ({ label: 'URL del anuncio' }),
        handleSaveField,
        { field: 'link' }
    );
    // Editable: disclaimer text
    useEditable(
        disclaimerRef,
        'text',
        () => ({ html: localDisclaimer }),
        () => ({}),
        handleSaveField,
        { field: 'disclaimer' }
    );

    return (
        <section className="ad-section">
            <div className="ad-container">
                <div className="ad-disclaimer" ref={disclaimerRef}>{localDisclaimer}</div>
                <div className="ad-large" ref={linkRef} onClick={e => { if (localLinkUrl === '#') e.preventDefault(); }}>
                    <a href={localLinkUrl} target="_blank" rel="noopener noreferrer">
                        <div ref={imgRef}>
                            <img src={localImageUrl} alt={localAlt} />
                        </div>
                    </a>
                </div>
            </div>
        </section>
    );
};

export default AdSection;
