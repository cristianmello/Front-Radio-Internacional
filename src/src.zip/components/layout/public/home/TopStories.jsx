// src/components/layout/public/home/TopStories.jsx
import React, { useState, useContext, useEffect, useCallback } from "react";
import PropTypes from "prop-types";
import StoryItem from "./StoryItem";
import "../../../../assets/css/TopStories.css";
import { AdminModeContext } from "../public/PublicLayout";
import EmptyPlaceholder from '../EmptyPlaceholder';

// 1. Defaults fuera del componente
const defaultStories = [
    {
        id: "1",
        imageUrl: "https://source.unsplash.com/random/600x400/?technology",
        alt: "Tecnología",
        category: "Tecnología",
        title: "Nueva inteligencia artificial revoluciona la medicina",
        excerpt:
            "El sistema puede diagnosticar enfermedades con mayor precisión que los médicos humanos.",
        linkUrl: "/articulo/1"
    },
    {
        id: "2",
        imageUrl: "https://source.unsplash.com/random/600x400/?economy",
        alt: "Economía",
        category: "Economía",
        title: "Mercados globales responden positivamente a reformas económicas",
        excerpt:
            "Las bolsas internacionales registran alzas históricas tras anuncio de nuevas políticas.",
        linkUrl: "/articulo/2"
    },
    {
        id: "3",
        imageUrl: "https://source.unsplash.com/random/600x400/?sports",
        alt: "Deportes",
        category: "Deportes",
        title: "Sorpresa en el mundial: favoritos eliminados en primera ronda",
        excerpt:
            "El equipo considerado invencible cae ante un rival que nadie consideraba.",
        linkUrl: "/articulo/3"
    }
];

const TopStories = ({
    initialStories = [],
    onUpdateStory,
    onDeleteStory
}) => {
    const { isAdminMode } = useContext(AdminModeContext);

    // 2. Estado local de historias
    const [stories, setStories] = useState(
        Array.isArray(initialStories) && initialStories.length > 0
            ? initialStories
            : defaultStories
    );

    // 3. Sincronizar si cambian las props
    useEffect(() => {
        if (Array.isArray(initialStories) && initialStories.length > 0) {
            setStories(initialStories);
        }
    }, [initialStories]);

    // 4. Handler memoizado para actualizar
    const handleUpdate = useCallback(
        (id, updatedFields) => {
            setStories((prev) =>
                prev.map((st) => (st.id === id ? { ...st, ...updatedFields } : st))
            );
            onUpdateStory?.(id, updatedFields);
        },
        [onUpdateStory]
    );

    return (
        <div className="top-stories">
            {stories.length === 0 ? (
                <EmptyPlaceholder
                    condition={true}
                    message="No hay historias en esta sección. Añada nuevas historias con el botón superior."
                />
            ) : (
                stories.map((story) => (
                    <StoryItem
                        key={story.id}
                        story={story}
                        isAdminMode={isAdminMode}
                        onUpdate={(fields) => handleUpdate(story.id, fields)}
                        onDelete={() => onDeleteStory(story.id)}
                    />
                ))
            )}
        </div>
    );
};

TopStories.propTypes = {
    initialStories: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            imageUrl: PropTypes.string.isRequired,
            alt: PropTypes.string,
            category: PropTypes.string.isRequired,
            title: PropTypes.string.isRequired,
            excerpt: PropTypes.string,
            linkUrl: PropTypes.string.isRequired
        })
    ),
    onUpdateStory: PropTypes.func,
    onDeleteStory: PropTypes.func
};

export default TopStories;
