// src/components/layout/public/home/ShortsSection.jsx
import React, {
    useState,
    useEffect,
    useContext,
    useRef,
    useCallback
} from "react";
import PropTypes from "prop-types";
import "../../../../assets/css/ShortSection.css";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";
import ShortItem from "./ShortItem";
import ConfirmDeleteModal from "../../../editing/modal/ConfirmDeleteModal";

const ShortsSection = ({
    apiEndpoint = "/api/shorts",
    onUpdateShort,
    onDeleteShort
}) => {
    const { isAdminMode } = useContext(AdminModeContext);

    const [shorts, setShorts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [toDeleteId, setToDeleteId] = useState(null);

    // Header editable
    const [headerText, setHeaderText] = useState("Shorts");
    const headerRef = useRef();
    const getHeaderValues = useCallback(() => ({ html: headerText }), [headerText]);
    const handleHeaderSave = useCallback(
        ({ html }) => setHeaderText(html),
        []
    );
    useEditable(
        headerRef,
        "text",
        getHeaderValues,
        () => ({}),
        handleHeaderSave,
        { field: "header" }
    );

    // Fetch shorts
    useEffect(() => {
        let isMounted = true;
        const fetchShorts = async () => {
            try {
                const res = await fetch(apiEndpoint);
                if (!res.ok) throw new Error(`Error ${res.status}`);
                const data = await res.json();
                if (!isMounted) return;
                setShorts(
                    Array.isArray(data)
                        ? data.map((s) => ({
                            id: s.id,
                            img: s.img || "",
                            title: s.title || "",
                            duration: s.duration || "",
                            views: s.views != null ? s.views : "",
                        }))
                        : []
                );
            } catch (err) {
                console.error("Failed to load shorts:", err);
                if (isMounted) setError("No se pudieron cargar los shorts");
            } finally {
                if (isMounted) setLoading(false);
            }
        };
        fetchShorts();
        return () => {
            isMounted = false;
        };
    }, [apiEndpoint]);

    // Update short callback
    const handleUpdateShort = useCallback(
        (shortId, updatedFields) => {
            setShorts((prev) =>
                prev.map((s) =>
                    s.id === shortId ? { ...s, ...updatedFields } : s
                )
            );
            onUpdateShort?.(shortId, updatedFields);
        },
        [onUpdateShort]
    );

    // Confirm delete callback
    const confirmDelete = useCallback(() => {
        setShorts((prev) => prev.filter((s) => s.id !== toDeleteId));
        onDeleteShort?.(toDeleteId);
        setToDeleteId(null);
    }, [toDeleteId, onDeleteShort]);

    // Render loading / error
    if (loading) {
        return (
            <section className="shorts-section">
                <div className="section-header">
                    <h2
                        ref={headerRef}
                        className={isAdminMode ? "editable" : ""}
                        {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
                    >
                        {headerText}
                    </h2>
                </div>
                <p>Cargando shorts...</p>
            </section>
        );
    }
    if (error) {
        return (
            <section className="shorts-section">
                <div className="section-header">
                    <h2
                        ref={headerRef}
                        className={isAdminMode ? "editable" : ""}
                        {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
                    >
                        {headerText}
                    </h2>
                </div>
                <p className="error">{error}</p>
            </section>
        );
    }

    return (
        <section className="shorts-section">
            <div className="section-header">
                <h2
                    ref={headerRef}
                    className={isAdminMode ? "editable" : ""}
                    {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
                >
                    {headerText}
                </h2>
            </div>

            <div className="shorts-container">
                {shorts.map((short) => (
                    <ShortItem
                        key={short.id}
                        short={short}
                        isAdminMode={isAdminMode}
                        onUpdateField={handleUpdateShort}
                        onDelete={() => setToDeleteId(short.id)}
                        onPlay={() => {
                            if (!isAdminMode) {
                                alert(`Reproducir short: "${short.title}" (${short.id})`);
                            }
                        }}
                    />
                ))}
            </div>

            <ConfirmDeleteModal
                isOpen={!!toDeleteId}
                type="short"
                onCancel={() => setToDeleteId(null)}
                onConfirm={confirmDelete}
            />
        </section>
    );
};

ShortsSection.propTypes = {
    apiEndpoint: PropTypes.string,
    onUpdateShort: PropTypes.func,
    onDeleteShort: PropTypes.func
};

export default ShortsSection;
