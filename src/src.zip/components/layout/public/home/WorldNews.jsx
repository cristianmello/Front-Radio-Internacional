// src/components/layout/public/home/WorldNews.jsx
import React, { useState, useRef, useContext } from "react";
import PropTypes from "prop-types";
import "../../../../assets/css/WorldNews.css";
import { AdminModeContext } from "../PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";

// Subcomponente MapMarker
const MapMarker = ({ continent, markerData, onClick, onUpdateMarker }) => {
    const { isAdminMode } = useContext(AdminModeContext);
    const titleRef = useRef();
    const previewRef = useRef();

    useEditable(
        titleRef,
        "text",
        () => ({ html: markerData.title }),
        () => ({}),
        (vals) => onUpdateMarker(continent, { title: vals.html }),
        { field: "markerTitle" }
    );
    useEditable(
        previewRef,
        "text",
        () => ({ html: markerData.preview }),
        () => ({}),
        (vals) => onUpdateMarker(continent, { preview: vals.html }),
        { field: "markerPreview" }
    );

    return (
        <div
            className={`news-marker ${continent}`}
            data-continent={continent}
            onClick={(e) => { e.stopPropagation(); onClick(continent); }}
            style={{ cursor: "pointer", position: "absolute" }}
        >
            <div className="marker-dot" />
            <div className="marker-pulse" />
            <div className="marker-preview">
                <h5 ref={titleRef} className={isAdminMode ? "editable" : ""}>
                    {markerData.title}
                </h5>
                <p ref={previewRef} className={isAdminMode ? "editable" : ""}>
                    {markerData.preview}
                </p>
            </div>
        </div>
    );
};

// Subcomponente ContinentNewsItem
const ContinentNewsItem = ({ continent, itemData, onUpdateItem }) => {
    const { isAdminMode } = useContext(AdminModeContext);
    const imgRef = useRef();
    const titleRef = useRef();
    const excerptRef = useRef();
    const [localData, setLocalData] = useState(itemData);

    const handleSaveField = (field, vals) => {
        const updated = {};
        switch (field) {
            case "image":
                updated.img = vals.src;
                updated.alt = vals.alt;
                break;
            case "title":
                updated.title = vals.html;
                break;
            case "excerpt":
                updated.excerpt = vals.html;
                break;
            default:
                return;
        }
        setLocalData(prev => ({ ...prev, ...updated }));
        onUpdateItem(continent, itemData.id, updated);
    };

    useEditable(
        imgRef,
        "image",
        () => ({ src: localData.img, alt: localData.alt }),
        () => ({ presets: [continent, "news", "map-news"] }),
        (vals) => handleSaveField("image", vals),
        { field: "image" }
    );
    useEditable(
        titleRef,
        "text",
        () => ({ html: localData.title }),
        () => ({}),
        (vals) => handleSaveField("title", vals),
        { field: "title" }
    );
    useEditable(
        excerptRef,
        "text",
        () => ({ html: localData.excerpt }),
        () => ({}),
        (vals) => handleSaveField("excerpt", vals),
        { field: "excerpt" }
    );

    return (
        <div className="continent-news-item">
            <div className="image-wrapper" ref={imgRef} style={{ cursor: isAdminMode ? "pointer" : "default" }}>
                <img src={localData.img} alt={localData.alt} />
            </div>
            <h5 ref={titleRef} className={isAdminMode ? "editable" : ""}>
                {localData.title}
            </h5>
            <p ref={excerptRef} className={isAdminMode ? "editable excerpt" : "excerpt"}>
                {localData.excerpt}
            </p>
        </div>
    );
};

// Componente principal WorldNews
const WorldNews = ({
    initialData,
    onUpdateMarker,
    onUpdateItem,
    onUpdateTabLabel,
    onUpdateMapImage,
}) => {
    const { isAdminMode } = useContext(AdminModeContext);
    const [activeContinent, setActiveContinent] = useState("europa");

    // Header editable
    const headerRef = useRef();
    const [headerText, setHeaderText] = useState("Noticias del Mundo");
    useEditable(
        headerRef,
        "text",
        () => ({ html: headerText }),
        () => ({}),
        (vals) => setHeaderText(vals.html),
        { field: "header" }
    );

    // Map image editable
    const mapImgRef = useRef();
    const [mapImageUrl, setMapImageUrl] = useState(
        (initialData && initialData.mapImageUrl) ||
        "https://source.unsplash.com/random/800x400/?world-map"
    );
    useEditable(
        mapImgRef,
        "image",
        () => ({ src: mapImageUrl, alt: "Mapa mundial" }),
        () => ({ presets: ["world-map", "globe", "map"] }),
        (vals) => {
            setMapImageUrl(vals.src);
            onUpdateMapImage?.(vals.src);
        },
        { field: "mapImage" }
    );

    // Tab labels editable
    const defaultTabLabels = {
        europa: "Europa",
        norteamerica: "Norteamérica",
        asia: "Asia",
        africa: "África",
        sudamerica: "Sudamérica",
        oceania: "Oceanía",
    };
    const [tabLabels, setTabLabels] = useState(
        (initialData && initialData.tabLabels) || defaultTabLabels
    );
    const tabLabelRefs = {};
    Object.keys(defaultTabLabels).forEach((cont) => {
        tabLabelRefs[cont] = useRef();
        useEditable(
            tabLabelRefs[cont],
            "text",
            () => ({ html: tabLabels[cont] }),
            () => ({}),
            (vals) => {
                setTabLabels((prev) => ({ ...prev, [cont]: vals.html }));
                onUpdateTabLabel?.(cont, vals.html);
            },
            { field: "tabLabel" }
        );
    });

    // World data defaults
    const defaultWorldData = (initialData && initialData.worldData) || {
        europa: {
            marker: { title: "Europa", preview: "Crisis energética afecta a múltiples países" },
            items: [
                { id: "europa-0", img: "https://source.unsplash.com/random/300x200/?europe", alt: "Europa noticia 1", title: "Acuerdo climático europeo entra en nueva fase de implementación", excerpt: "Las naciones europeas refuerzan sus compromisos para reducir emisiones antes de 2030." },
                { id: "europa-1", img: "https://source.unsplash.com/random/300x200/?europe-politics", alt: "Europa noticia 2", title: "Tensiones comerciales amenazan estabilidad del mercado común", excerpt: "Negociaciones maratónicas buscan resolver disputas entre estados miembros." },
                { id: "europa-2", img: "https://source.unsplash.com/random/300x200/?europe-culture", alt: "Europa noticia 3", title: "Festival cultural transfronterizo celebra diversidad regional", excerpt: "Artistas de toda Europa participan en iniciativa para fortalecer lazos culturales." },
            ],
        },
        norteamerica: {
            marker: { title: "Norteamérica", preview: "Avances en política ambiental generan esperanza" },
            items: [
                { id: "norteamerica-0", img: "https://source.unsplash.com/random/300x200/?north-america", alt: "Norteamérica noticia 1", title: "Políticas ambientales impulsan energías limpias", excerpt: "Gobiernos y empresas invierten en tecnologías para reducir huella de carbono." },
            ],
        },
        asia: {
            marker: { title: "Asia", preview: "Crecimiento económico supera las expectativas" },
            items: [
                { id: "asia-0", img: "https://source.unsplash.com/random/300x200/?asia", alt: "Asia noticia 1", title: "Crecimiento económico acelera en varias potencias asiáticas", excerpt: "Sectores tecnológicos y manufactura registran mayor dinamismo." },
            ],
        },
        africa: {
            marker: { title: "África", preview: "Innovaciones en agricultura transforman comunidades" },
            items: [
                { id: "africa-0", img: "https://source.unsplash.com/random/300x200/?africa", alt: "África noticia 1", title: "Agricultura sostenible impulsa economías locales", excerpt: "Nuevas técnicas mejoran rendimiento y resiliencia ante el cambio climático." },
            ],
        },
        sudamerica: {
            marker: { title: "Sudamérica", preview: "Acuerdo comercial histórico entre naciones vecinas" },
            items: [
                { id: "sudamerica-0", img: "https://source.unsplash.com/random/300x200/?south-america", alt: "Sudamérica noticia 1", title: "Nuevos tratados impulsan comercio regional", excerpt: "Economías vecinas firman acuerdos para facilitar exportaciones e inversiones." },
            ],
        },
        oceania: {
            marker: { title: "Oceanía", preview: "Medidas pioneras contra el cambio climático" },
            items: [
                { id: "oceania-0", img: "https://source.unsplash.com/random/300x200/?oceania", alt: "Oceanía noticia 1", title: "Iniciativas medioambientales lideran en Oceanía", excerpt: "Proyectos de conservación y energías renovables marcan la pauta." },
            ],
        },
    };
    const [worldData, setWorldData] = useState(defaultWorldData);

    const handleUpdateMarker = (continent, updated) => {
        setWorldData((prev) => ({
            ...prev,
            [continent]: { ...prev[continent], marker: { ...prev[continent].marker, ...updated } },
        }));
        onUpdateMarker?.(continent, updated);
    };
    const handleUpdateItem = (continent, itemId, updated) => {
        setWorldData((prev) => ({
            ...prev,
            [continent]: {
                ...prev[continent],
                items: prev[continent].items.map((i) =>
                    i.id === itemId ? { ...i, ...updated } : i
                ),
            },
        }));
        onUpdateItem?.(continent, itemId, updated);
    };

    const activateContinent = (cont) => setActiveContinent(cont);

    return (
        <section className="world-news">
            <div className="section-header">
                <h2
                    ref={headerRef}
                    className={isAdminMode ? "editable" : ""}
                >
                    {headerText}
                </h2>
            </div>
            <div className="world-map-news">
                <div className="world-map" style={{ position: "relative" }}>
                    <div
                        ref={mapImgRef}
                        className={isAdminMode ? "editable" : ""}
                        style={{ cursor: isAdminMode ? "pointer" : "default" }}
                    >
                        <img src={mapImageUrl} alt="Mapa mundial" />
                    </div>
                    {Object.keys(worldData).map((cont) => (
                        <MapMarker
                            key={cont}
                            continent={cont}
                            markerData={worldData[cont].marker}
                            onClick={activateContinent}
                            onUpdateMarker={handleUpdateMarker}
                        />
                    ))}
                </div>
            </div>
            <div className="continent-tabs">
                {Object.keys(tabLabels).map((cont) => (
                    <button
                        key={cont}
                        ref={tabLabelRefs[cont]}
                        className={`continent-tab ${activeContinent === cont ? "active" : ""} ${isAdminMode ? "editable" : ""}`}
                        onClick={() => activateContinent(cont)}
                    >
                        {tabLabels[cont]}
                    </button>
                ))}
            </div>
            <div className="continent-content">
                <div className="continent-news-grid">
                    {worldData[activeContinent].items.map((item) => (
                        <ContinentNewsItem
                            key={item.id}
                            continent={activeContinent}
                            itemData={item}
                            onUpdateItem={handleUpdateItem}
                        />
                    ))}
                </div>
            </div>
        </section>
    );
};

WorldNews.propTypes = {
    initialData: PropTypes.shape({
        mapImageUrl: PropTypes.string,
        tabLabels: PropTypes.object,
        worldData: PropTypes.object,
    }),
    onUpdateMarker: PropTypes.func,
    onUpdateItem: PropTypes.func,
    onUpdateTabLabel: PropTypes.func,
    onUpdateMapImage: PropTypes.func,
};

export default WorldNews;
