import React, { useState, useEffect, useRef } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { useEditable } from "../../../../hooks/useEditable";

const defaultData = {
  heading: "Temas Populares",
  tags: [
    { id: "t1", text: "Coronavirus", linkUrl: "/tag/coronavirus" },
    { id: "t2", text: "Economía", linkUrl: "/tag/economia" },
    { id: "t3", text: "Elecciones", linkUrl: "/tag/elecciones" },
    { id: "t4", text: "Cambio climático", linkUrl: "/tag/cambio-climatico" },
    { id: "t5", text: "Tecnología", linkUrl: "/tag/tecnologia" },
    { id: "t6", text: "Deportes", linkUrl: "/tag/deportes" },
  ],
};

export default function TagsWidget({ isAdminMode, initialData, onUpdate }) {
  const [data, setData] = useState({ ...defaultData, ...initialData });
  useEffect(() => { setData({ ...defaultData, ...initialData }); }, [initialData]);

  const updateTag = (id, fields) => {
    setData(prev => ({
      ...prev,
      tags: prev.tags.map(t => t.id === id ? { ...t, ...fields } : t)
    }));
    onUpdate?.(id, fields);
  };

  const headingRef = useRef();
  useEditable(headingRef, "text", () => ({ html: data.heading }), () => ({}), vals => setData(prev => ({ ...prev, heading: vals.html })), { field: "heading" });

  const tagRefs = useRef({});
  data.tags.forEach(t => {
    if (!tagRefs.current[t.id]) tagRefs.current[t.id] = { textRef: React.createRef(), linkRef: React.createRef() };

    useEditable(tagRefs.current[t.id].textRef, "text", () => ({ html: t.text }), () => ({}), vals => updateTag(t.id, { text: vals.html }), { field: "tagText" });
    useEditable(tagRefs.current[t.id].linkRef, "link", () => ({ href: t.linkUrl }), () => ({ label: "URL de la etiqueta" }), vals => updateTag(t.id, { linkUrl: vals.href }), { field: "tagLink" });
  });

  return (
    <div className="widget tags">
      <h3 ref={headingRef} className={isAdminMode?"editable":""} style={{ cursor: isAdminMode?"pointer":"default" }}>
        {data.heading}
      </h3>
      <div className="tag-cloud">
        {data.tags.map(t => (
          <Link
            key={t.id}
            ref={tagRefs.current[t.id].textRef}
            to={t.linkUrl}
            className="tag"
            onClick={e => isAdminMode && e.preventDefault()}
            style={{ cursor: isAdminMode?"pointer":"default" }}
          >
            {t.text}
            <span ref={tagRefs.current[t.id].linkRef} style={{ display: "none" }} />
          </Link>
        ))}
      </div>
    </div>
  );
}

TagsWidget.propTypes = {
  isAdminMode: PropTypes.bool,
  initialData: PropTypes.object,
  onUpdate: PropTypes.func,
};
