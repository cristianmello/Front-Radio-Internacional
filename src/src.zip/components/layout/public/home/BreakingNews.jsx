// src/components/layout/public/home/BreakingNews.jsx
import React, {
  useState,
  useRef,
  useContext,
  useEffect,
  useCallback
} from "react";
import PropTypes from "prop-types";
import FeaturedArticle from "./FeaturedArticle";
import TopStories from "./TopStories";
import "../../../../assets/css/BreakingNews.css";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";
import ConfirmDeleteModal from "../../../editing/modal/ConfirmDeleteModal";

// 1. Defaults fuera del componente
const defaultFeatured = {
  id: "featured-1",
  imageUrl: "https://source.unsplash.com/random/1200x600/?news",
  alt: "Noticia principal",
  badgeText: "ÚLTIMA HORA",
  badgeClass: "breaking",
  category: "Política",
  title: "Histórico acuerdo de paz firmado entre naciones en conflicto",
  excerpt:
    "Tras décadas de tensiones, los líderes mundiales celebran el tratado que promete estabilidad en la región y nuevas oportunidades de cooperación internacional.",
  author: "María González",
  date: "Hace 2 horas",
  readTime: "5 min lectura"
};

const defaultStories = [
  {
    id: "ts1",
    imageUrl: "https://source.unsplash.com/random/600x400/?technology",
    alt: "Tecnología",
    category: "Tecnología",
    title: "Nueva inteligencia artificial revoluciona la medicina",
    excerpt:
      "El sistema puede diagnosticar enfermedades con mayor precisión que los médicos humanos.",
    linkUrl: "/articulo/1"
  },
  {
    id: "ts2",
    imageUrl: "https://source.unsplash.com/random/600x400/?economy",
    alt: "Economía",
    category: "Economía",
    title: "Mercados globales responden positivamente a reformas económicas",
    excerpt:
      "Las bolsas internacionales registran alzas históricas tras anuncio de nuevas políticas.",
    linkUrl: "/articulo/2"
  },
  {
    id: "ts3",
    imageUrl: "https://source.unsplash.com/random/600x400/?sports",
    alt: "Deportes",
    category: "Deportes",
    title: "Sorpresa en el mundial: favoritos eliminados en primera ronda",
    excerpt:
      "El equipo considerado invencible cae ante un rival que nadie consideraba.",
    linkUrl: "/articulo/3"
  }
];

const BreakingNews = ({
  initialFeatured = null,
  initialTopStories = [],
  onUpdateFeatured,
  onUpdateTopStory,
  onUpdateHeader,
  onDeleteFeatured,
  onDeleteTopStory
}) => {
  const { isAdminMode } = useContext(AdminModeContext);

  // Estado confirmación borrado
  const [toDelete, setToDelete] = useState(null);

  // ----- Header editable -----
  const [headerText, setHeaderText] = useState("Últimas Noticias");
  const headerRef = useRef();

  const getHeaderValues = useCallback(() => ({ html: headerText }), [headerText]);
  const handleHeaderSave = useCallback(
    ({ html }) => {
      setHeaderText(html);
      onUpdateHeader?.(html);
    },
    [onUpdateHeader]
  );

  useEditable(
    headerRef,
    "text",
    getHeaderValues,
    () => ({}),
    handleHeaderSave,
    { field: "header" }
  );

  // ----- FeaturedArticle en estado local -----
  const [featuredData, setFeaturedData] = useState(() => {
    if (initialFeatured) {
      return {
        ...defaultFeatured,
        ...initialFeatured,
        id: String(initialFeatured.id)
      };
    }
    return defaultFeatured;
  });

  useEffect(() => {
    if (initialFeatured) {
      setFeaturedData((prev) => ({
        ...prev,
        ...initialFeatured,
        id: String(initialFeatured.id)
      }));
    }
  }, [initialFeatured]);

  const handleUpdateFeat = useCallback(
    (id, updatedFields) => {
      setFeaturedData((prev) => ({ ...prev, ...updatedFields }));
      onUpdateFeatured?.(id, updatedFields);
    },
    [onUpdateFeatured]
  );

  const handleDeleteFeat = useCallback(() => {
    setFeaturedData(null);
    onDeleteFeatured?.(featuredData.id);
    setToDelete(null);
  }, [featuredData, onDeleteFeatured]);

  // ----- TopStories en estado local -----
  const [topStoriesData, setTopStoriesData] = useState(() =>
    initialTopStories.length
      ? initialTopStories.map((st) => ({ ...st, id: String(st.id) }))
      : defaultStories
  );

  useEffect(() => {
    if (initialTopStories.length) {
      setTopStoriesData(
        initialTopStories.map((st) => ({ ...st, id: String(st.id) }))
      );
    }
  }, [initialTopStories]);

  const handleUpdateStory = useCallback(
    (storyId, fields) => {
      setTopStoriesData((prev) =>
        prev.map((st) =>
          st.id === String(storyId) ? { ...st, ...fields } : st
        )
      );
      onUpdateTopStory?.(storyId, fields);
    },
    [onUpdateTopStory]
  );

  const handleDeleteStory = useCallback(() => {
    setTopStoriesData((prev) =>
      prev.filter((s) => s.id !== toDelete.id)
    );
    onDeleteTopStory?.(toDelete.id);
    setToDelete(null);
  }, [toDelete, onDeleteTopStory]);

  return (
    <section className="breaking-news" id="inicio">
      <div className="section-header">
        <h2
          ref={headerRef}
          className={isAdminMode ? "editable" : ""}
          {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
        >
          {headerText}
        </h2>
      </div>

      {featuredData && (
        <FeaturedArticle
          {...featuredData}
          onUpdate={handleUpdateFeat}
          onDelete={() => setToDelete({ type: "featured", id: featuredData.id })}
        />
      )}

      <TopStories
        initialStories={topStoriesData}
        onUpdateStory={handleUpdateStory}
        onDeleteStory={(id) => setToDelete({ type: "story", id })}
      />

      <ConfirmDeleteModal
        isOpen={!!toDelete}
        type={toDelete?.type === "featured" ? "artículo destacado" : "historia secundaria"}
        onCancel={() => setToDelete(null)}
        onConfirm={toDelete?.type === "featured" ? handleDeleteFeat : handleDeleteStory}
      />
    </section>
  );
};

BreakingNews.propTypes = {
  initialFeatured: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    imageUrl: PropTypes.string,
    alt: PropTypes.string,
    badgeText: PropTypes.string,
    badgeClass: PropTypes.string,
    category: PropTypes.string,
    title: PropTypes.string,
    excerpt: PropTypes.string,
    author: PropTypes.string,
    date: PropTypes.string,
    readTime: PropTypes.string
  }),
  initialTopStories: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      imageUrl: PropTypes.string,
      alt: PropTypes.string,
      category: PropTypes.string,
      title: PropTypes.string,
      excerpt: PropTypes.string,
      linkUrl: PropTypes.string
    })
  ),
  onUpdateFeatured: PropTypes.func,
  onUpdateTopStory: PropTypes.func,
  onUpdateHeader: PropTypes.func,
  onDeleteFeatured: PropTypes.func,
  onDeleteTopStory: PropTypes.func
};

export default BreakingNews;
