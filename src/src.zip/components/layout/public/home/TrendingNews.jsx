// src/components/layout/public/home/TrendingNews.jsx
import React, { useState, useEffect, useRef, useContext } from "react";
import PropTypes from "prop-types";
import "../../../../assets/css/TrendingNews.css";
import TrendingCard from "./TrendingCard";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";

const TrendingNews = ({
    initialItems = [],
    onUpdateItem,
    onDeleteItem,
}) => {
    const { isAdminMode } = useContext(AdminModeContext);

    // Valores por defecto
    const defaultItems = [
        { id: "t1", imageUrl: "https://source.unsplash.com/random/400x300/?entertainment", alt: "Entretenimiento", category: "Entretenimiento", title: "Festival de cine anuncia selección oficial con sorpresas", excerpt: "Nuevos talentos y directores consagrados competirán por el prestigioso premio.", date: "Ayer", linkUrl: "/articulo/6" },
        { id: "t2", imageUrl: "https://source.unsplash.com/random/400x300/?science", alt: "Ciencia", category: "Ciencia", title: "Descubren planeta potencialmente habitable a solo 40 años luz", excerpt: "Científicos detectan condiciones similares a la Tierra en sistema estelar cercano.", date: "Hace 3 días", linkUrl: "/articulo/7" },
        { id: "t3", imageUrl: "https://source.unsplash.com/random/400x300/?politics", alt: "Política", category: "Política", title: "Elecciones anticipadas sorprenden al panorama político", excerpt: "El anuncio genera incertidumbre y realineamientos en los partidos tradicionales.", date: "Hace 1 día", linkUrl: "/articulo/8" },
        { id: "t4", imageUrl: "https://source.unsplash.com/random/400x300/?health", alt: "Salud", category: "Salud", title: "Nuevo tratamiento contra el cáncer muestra resultados prometedores", excerpt: "Ensayos clínicos revelan eficacia sin precedentes en casos avanzados.", date: "Hace 2 días", linkUrl: "/articulo/9" },
    ];

    const [items, setItems] = useState(initialItems.length ? initialItems : defaultItems);
    useEffect(() => {
        if (initialItems.length) setItems(initialItems);
    }, [initialItems]);

    const handleUpdate = (id, updatedFields) => {
        setItems(prev => prev.map(it => it.id === id ? { ...it, ...updatedFields } : it));
        onUpdateItem?.(id, updatedFields);
    };
    const handleDelete = (id) => {
        setItems(prev => prev.filter(it => it.id !== id));
        onDeleteItem?.(id);
    };

    // Header editable
    const headerRef = useRef();
    const [headerText, setHeaderText] = useState("Tendencias");
    useEditable(
        headerRef,
        "text",
        () => ({ html: headerText }),
        () => ({}),
        (vals) => setHeaderText(vals.html),
        { field: "trendingHeader" }
    );

    return (
        <section className="trending-news">
            <div className="section-header">
                <h2
                    ref={headerRef}
                    className={isAdminMode ? "editable" : ""}
                    {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
                >
                    {headerText}
                </h2>
            </div>
            <div className="news-grid">
                {items.map(item => (
                    <TrendingCard
                        key={item.id}
                        item={item}
                        isAdminMode={isAdminMode}
                        onUpdate={handleUpdate}
                        onDelete={() => handleDelete(item.id)}
                    />
                ))}
            </div>
        </section>
    );
};

TrendingNews.propTypes = {
    initialItems: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            imageUrl: PropTypes.string.isRequired,
            alt: PropTypes.string,
            category: PropTypes.string.isRequired,
            title: PropTypes.string.isRequired,
            excerpt: PropTypes.string,
            date: PropTypes.string.isRequired,
            linkUrl: PropTypes.string.isRequired,
        })
    ),
    onUpdateItem: PropTypes.func,
    onDeleteItem: PropTypes.func,
};

export default TrendingNews;
