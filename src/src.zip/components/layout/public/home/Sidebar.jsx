import React, { useState, useEffect, useContext } from "react";
import "../../../../assets/css/Sidebar.css";
import { AdminModeContext } from "../public/PublicLayout";
import PopularPosts from "./Sidebar/PopularPosts";
import NewsletterWidget from "./Sidebar/NewsletterWidget";
import AdWidget from "./Sidebar/AdWidget";
import TagsWidget from "./Sidebar/TagsWidget";

const Sidebar = ({
  initialPopularPosts = [],
  onUpdatePopularPost,
  onDeletePopularPost,
  initialNewsletter = {},
  onUpdateNewsletter,
  initialAd = {},
  onUpdateAd,
  initialTags = {},
  onUpdateTag,
}) => {
  const { isAdminMode } = useContext(AdminModeContext);

  return (
    <aside className="sidebar">
      <PopularPosts
        isAdminMode={isAdminMode}
        initialItems={initialPopularPosts}
        onUpdate={onUpdatePopularPost}
        onDelete={onDeletePopularPost}
      />
      <NewsletterWidget
        isAdminMode={isAdminMode}
        initialData={initialNewsletter}
        onUpdate={onUpdateNewsletter}
      />
      <AdWidget
        isAdminMode={isAdminMode}
        initialData={initialAd}
        onUpdate={onUpdateAd}
      />
      <TagsWidget
        isAdminMode={isAdminMode}
        initialData={initialTags}
        onUpdate={onUpdateTag}
      />
    </aside>
  );
};

export default Sidebar;
