// src/components/layout/public/home/FeaturedArticle.jsx
import React, { useState, useRef, useContext, useCallback } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";
import "./FeaturedArticle.css"; // Define aquí .editable, .badge.editable, .delete-item-btn, etc.

const FeaturedArticle = ({
    id,
    imageUrl,
    alt,
    badgeText,
    badgeClass,
    category,
    title,
    excerpt,
    author,
    date,
    readTime,
    onUpdate,
    onDelete
}) => {
    const { isAdminMode } = useContext(AdminModeContext);

    // Estados locales inicializados desde props
    const [localImageUrl, setLocalImageUrl] = useState(imageUrl);
    const [localAlt, setLocalAlt] = useState(alt);
    const [localBadgeText, setLocalBadgeText] = useState(badgeText);
    const [localCategory, setLocalCategory] = useState(category);
    const [localTitle, setLocalTitle] = useState(title);
    const [localExcerpt, setLocalExcerpt] = useState(excerpt);
    const [localAuthor, setLocalAuthor] = useState(author);
    const [localDate, setLocalDate] = useState(date);
    const [localReadTime, setLocalReadTime] = useState(readTime);

    // Refs para cada campo editable
    const imgRef = useRef();
    const badgeRef = useRef();
    const categoryRef = useRef();
    const titleRef = useRef();
    const excerptRef = useRef();
    const authorRef = useRef();
    const dateRef = useRef();
    const readTimeRef = useRef();

    // Callback genérico para guardar cambios
    const handleSaveField = useCallback(
        (newValues, meta) => {
            const updated = {};
            switch (meta.field) {
                case "image":
                    setLocalImageUrl(newValues.src);
                    setLocalAlt(newValues.alt);
                    updated.imageUrl = newValues.src;
                    updated.alt = newValues.alt;
                    break;
                case "badge":
                    setLocalBadgeText(newValues.html);
                    updated.badgeText = newValues.html;
                    break;
                case "category":
                    setLocalCategory(newValues.text);
                    updated.category = newValues.text;
                    break;
                case "title":
                    setLocalTitle(newValues.html);
                    updated.title = newValues.html;
                    break;
                case "excerpt":
                    setLocalExcerpt(newValues.html);
                    updated.excerpt = newValues.html;
                    break;
                case "author":
                    setLocalAuthor(newValues.text);
                    updated.author = newValues.text;
                    break;
                case "date":
                    setLocalDate(newValues.text);
                    updated.date = newValues.text;
                    break;
                case "read-time":
                    setLocalReadTime(newValues.text);
                    updated.readTime = newValues.text;
                    break;
                default:
                    return;
            }
            onUpdate?.(id, updated);
        },
        [id, onUpdate]
    );

    // Registro de cada parte como editable
    useEditable(
        imgRef,
        "image",
        () => ({ src: localImageUrl, alt: localAlt }),
        () => ({ presets: ["news", "breaking-news", "headline"] }),
        handleSaveField,
        { field: "image" }
    );

    useEditable(
        badgeRef,
        "text",
        () => ({ html: localBadgeText }),
        () => ({}),
        handleSaveField,
        { field: "badge" }
    );

    useEditable(
        categoryRef,
        "category",
        () => ({ text: localCategory }),
        () => ({ categories: ["Política", "Economía", "Tecnología", "Deportes", "Cultura"] }),
        handleSaveField,
        { field: "category" }
    );

    useEditable(
        titleRef,
        "text",
        () => ({ html: localTitle }),
        () => ({}),
        handleSaveField,
        { field: "title" }
    );

    useEditable(
        excerptRef,
        "text",
        () => ({ html: localExcerpt }),
        () => ({}),
        handleSaveField,
        { field: "excerpt" }
    );

    useEditable(
        authorRef,
        "text",
        () => ({ text: localAuthor }),
        () => ({}),
        handleSaveField,
        { field: "author" }
    );

    useEditable(
        dateRef,
        "date",
        () => ({ text: localDate }),
        () => ({
            label: "Fecha:",
            quickDates: ["Ahora", "Hace 1 hora", "Hace 2 horas", "Ayer", "Hace 2 días"]
        }),
        handleSaveField,
        { field: "date" }
    );

    useEditable(
        readTimeRef,
        "read-time",
        () => ({ text: localReadTime }),
        () => ({ label: "Tiempo de lectura:" }),
        handleSaveField,
        { field: "read-time" }
    );

    return (
        <div className="featured-article">
            {isAdminMode && (
                <button
                    className="delete-item-btn"
                    onClick={onDelete}
                    aria-label="Eliminar artículo destacado"
                >
                    🗑
                </button>
            )}
            <div className="article-image">
                <div
                    ref={badgeRef}
                    className={`badge ${badgeClass} editable`}
                    role={isAdminMode ? "button" : undefined}
                    tabIndex={isAdminMode ? 0 : undefined}
                >
                    {localBadgeText}
                </div>
                <img
                    ref={imgRef}
                    src={localImageUrl}
                    alt={localAlt}
                    className={isAdminMode ? "editable" : ""}
                />
            </div>
            <div className="article-content">
                <span
                    ref={categoryRef}
                    className={`category ${isAdminMode ? "editable" : ""}`}
                    role={isAdminMode ? "button" : undefined}
                    tabIndex={isAdminMode ? 0 : undefined}
                >
                    {localCategory}
                </span>
                <h3
                    ref={titleRef}
                    className={isAdminMode ? "editable" : ""}
                    role={isAdminMode ? "button" : undefined}
                    tabIndex={isAdminMode ? 0 : undefined}
                >
                    {localTitle}
                </h3>
                <p
                    ref={excerptRef}
                    className={`excerpt ${isAdminMode ? "editable" : ""}`}
                    role={isAdminMode ? "button" : undefined}
                    tabIndex={isAdminMode ? 0 : undefined}
                >
                    {localExcerpt}
                </p>
                <div className="article-meta">
                    <span
                        ref={authorRef}
                        className={isAdminMode ? "editable author" : "author"}
                        role={isAdminMode ? "button" : undefined}
                        tabIndex={isAdminMode ? 0 : undefined}
                    >
                        Por {localAuthor}
                    </span>
                    <span
                        ref={dateRef}
                        className={isAdminMode ? "editable date" : "date"}
                        role={isAdminMode ? "button" : undefined}
                        tabIndex={isAdminMode ? 0 : undefined}
                    >
                        {localDate}
                    </span>
                    <span
                        ref={readTimeRef}
                        className={isAdminMode ? "editable read-time" : "read-time"}
                        role={isAdminMode ? "button" : undefined}
                        tabIndex={isAdminMode ? 0 : undefined}
                    >
                        {localReadTime}
                    </span>
                </div>
                <Link to={`/articulo/${id}`} className="read-more">
                    Leer más
                </Link>
            </div>
        </div>
    );
};

FeaturedArticle.propTypes = {
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    imageUrl: PropTypes.string.isRequired,
    alt: PropTypes.string,
    badgeText: PropTypes.string,
    badgeClass: PropTypes.string,
    category: PropTypes.string,
    title: PropTypes.string,
    excerpt: PropTypes.string,
    author: PropTypes.string,
    date: PropTypes.string,
    readTime: PropTypes.string,
    onUpdate: PropTypes.func,
    onDelete: PropTypes.func
};

export default FeaturedArticle;
