// src/components/layout/public/home/MosaicItem.jsx
import React, { useState, useRef, useContext, useCallback } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { AdminModeContext } from "../public/PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";
import "./MosaicItem.css"; // Asegúrate de definir aquí .editable, .mosaic-item.large, etc.

const MosaicItem = ({ item, onUpdate }) => {
  const { isAdminMode } = useContext(AdminModeContext);
  const { id, size = "" } = item;

  // --- Estados locales inicializados desde props ---
  const [localImageUrl, setLocalImageUrl] = useState(item.imageUrl);
  const [localAlt, setLocalAlt] = useState(item.alt || "");
  const [localCategory, setLocalCategory] = useState(item.category);
  const [localTitle, setLocalTitle] = useState(item.title);
  const [localExcerpt, setLocalExcerpt] = useState(item.excerpt || "");
  const [localLinkUrl, setLocalLinkUrl] = useState(item.linkUrl || "#");

  // --- Refs para cada campo editable ---
  const imgRef = useRef();
  const categoryRef = useRef();
  const titleRef = useRef();
  const excerptRef = useRef();
  const linkRef = useRef();

  // --- Callback para persistir cambios ---
  const handleSaveField = useCallback(
    (newValues, meta) => {
      const { field } = meta;
      const updated = {};

      switch (field) {
        case "image":
          setLocalImageUrl(newValues.src);
          setLocalAlt(newValues.alt || "");
          updated.imageUrl = newValues.src;
          updated.alt = newValues.alt;
          break;
        case "category":
          setLocalCategory(newValues.text);
          updated.category = newValues.text;
          break;
        case "title":
          setLocalTitle(newValues.html);
          updated.title = newValues.html;
          break;
        case "excerpt":
          setLocalExcerpt(newValues.html);
          updated.excerpt = newValues.html;
          break;
        case "link":
          setLocalLinkUrl(newValues.href);
          updated.linkUrl = newValues.href;
          break;
        default:
          return;
      }

      if (Object.keys(updated).length && typeof onUpdate === "function") {
        onUpdate(id, updated);
      }
    },
    [id, onUpdate]
  );

  // --- Registro de ediciones con useEditable ---
  useEditable(
    imgRef,
    "image",
    () => ({ src: localImageUrl, alt: localAlt }),
    () => ({ presets: ["breaking-news", "finance", "innovation", "culture", "fashion", "gastronomy"] }),
    (vals) => handleSaveField(vals, { field: "image" }),
    { field: "image" }
  );

  useEditable(
    categoryRef,
    "category",
    () => ({ text: localCategory }),
    () => ({
      categories: [
        "Internacional",
        "Finanzas",
        "Innovación",
        "Cultura",
        "Moda",
        "Gastronomía"
      ]
    }),
    (vals) => handleSaveField(vals, { field: "category" }),
    { field: "category" }
  );

  useEditable(
    titleRef,
    "text",
    () => ({ html: localTitle }),
    () => ({}),
    (vals) => handleSaveField(vals, { field: "title" }),
    { field: "title" }
  );

  useEditable(
    excerptRef,
    "text",
    () => ({ html: localExcerpt }),
    () => ({}),
    (vals) => handleSaveField(vals, { field: "excerpt" }),
    { field: "excerpt" }
  );

  useEditable(
    linkRef,
    "link",
    () => ({ href: localLinkUrl }),
    () => ({ label: "URL del artículo" }),
    (vals) => handleSaveField(vals, { field: "link" }),
    { field: "link" }
  );

  // --- Clases dinámicas según tamaño ---
  const sizeClass = size ? ` ${size}` : "";

  return (
    <div className={`mosaic-item${sizeClass}`}>
      <div
        className="mosaic-image editable"
        ref={imgRef}
        aria-label={isAdminMode ? "Editar imagen" : undefined}
      >
        <img src={localImageUrl} alt={localAlt} />
      </div>
      <div className="mosaic-content">
        <span
          className="category editable"
          ref={categoryRef}
          aria-label={isAdminMode ? "Editar categoría" : undefined}
        >
          {localCategory}
        </span>
        <h3
          className="editable"
          ref={titleRef}
          aria-label={isAdminMode ? "Editar título" : undefined}
        >
          {localTitle}
        </h3>
        <p
          className={`excerpt${!localExcerpt ? " empty" : ""} editable`}
          ref={excerptRef}
          aria-label={isAdminMode ? "Editar extracto" : undefined}
        >
          {localExcerpt || "Añadir extracto..."}
        </p>
        <Link
          to={localLinkUrl}
          className="read-more editable"
          ref={linkRef}
          aria-label={isAdminMode ? "Editar enlace" : undefined}
          onClick={(e) => {
            // Evitar navegación si no hay URL válida en modo admin
            if (isAdminMode && (!localLinkUrl || localLinkUrl === "#")) {
              e.preventDefault();
            }
          }}
        >
          Leer más
        </Link>
      </div>
    </div>
  );
};

MosaicItem.propTypes = {
  item: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    size: PropTypes.string,
    imageUrl: PropTypes.string.isRequired,
    alt: PropTypes.string,
    category: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    excerpt: PropTypes.string,
    linkUrl: PropTypes.string.isRequired
  }).isRequired,
  onUpdate: PropTypes.func
};

export default MosaicItem;
