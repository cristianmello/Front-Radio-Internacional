// src/components/layout/public/home/VideoNews.jsx
import React, { useContext, useState, useEffect, useRef } from "react";
import PropTypes from "prop-types";
import useResponsiveVideos from "../../../../hooks/UseResponviveVideos";
import "../../../../assets/css/VideoNews.css";
import { AdminModeContext } from "../public/PublicLayout";
import VideoCard from "./VideoCard";
import { useEditable } from "../../../../hooks/useEditable";

/**
 * Sección de videos con edición y eliminación en modo admin.
 */
const VideoNews = ({
    initialVideos = [],
    onDeleteVideo,
    onUpdateVideo,
}) => {
    useResponsiveVideos();
    const { isAdminMode, isAdminUser } = useContext(AdminModeContext);

    const defaultVideos = [
        { id: 1, thumb: "conference", title: "Cumbre mundial aborda crisis climática", duration: "15:42", url: "/videos/1", category: "Noticias" },
        { id: 2, thumb: "interview", title: "Entrevista exclusiva con autor bestseller", duration: "8:27", url: "/videos/2", category: "Entrevistas" },
        { id: 3, thumb: "documentary", title: "Documental revela hallazgos arqueológicos", duration: "22:15", url: "/videos/3", category: "Documentales" },
    ];

    const [videos, setVideos] = useState(
        Array.isArray(initialVideos) && initialVideos.length
            ? initialVideos.map(v => ({
                id: v.id,
                thumb: v.thumb || "",
                title: v.title || "",
                duration: v.duration || "",
                url: v.url || "#",
                category: v.category || "",
            }))
            : defaultVideos
    );

    useEffect(() => {
        if (Array.isArray(initialVideos) && initialVideos.length) {
            setVideos(
                initialVideos.map(v => ({
                    id: v.id,
                    thumb: v.thumb || "",
                    title: v.title || "",
                    duration: v.duration || "",
                    url: v.url || "#",
                    category: v.category || "",
                }))
            );
        }
    }, [initialVideos]);

    const [playingVideo, setPlayingVideo] = useState(null);

    const playVideo = video => setPlayingVideo(video);
    const closePlayer = () => setPlayingVideo(null);

    const handleDelete = video => {
        if (!isAdminMode || !isAdminUser) return;
        if (window.confirm(`¿Eliminar "${video.title}"?`)) {
            setVideos(prev => prev.filter(v => v.id !== video.id));
            onDeleteVideo?.(video.id);
        }
    };

    const handleUpdateField = (id, updatedFields) => {
        setVideos(prev => prev.map(v => (v.id === id ? { ...v, ...updatedFields } : v)));
        onUpdateVideo?.(id, updatedFields);
    };

    // Editable del encabezado
    const headerRef = useRef();
    const [headerText, setHeaderText] = useState("En Video");
    useEditable(
        headerRef,
        "text",
        () => ({ html: headerText }),
        () => ({}),
        vals => setHeaderText(vals.html),
        { field: "videoHeader" }
    );

    return (
        <section className="video-news">
            <div className="section-header">
                <h2
                    ref={headerRef}
                    className={isAdminMode ? "editable" : ""}
                    {...(isAdminMode ? { role: "button", tabIndex: 0 } : {})}
                >
                    {headerText}
                </h2>
            </div>

            <div className="video-grid">
                {videos.map(video => (
                    <VideoCard
                        key={video.id}
                        video={video}
                        isAdminMode={isAdminMode && isAdminUser}
                        onPlay={() => playVideo(video)}
                        onDelete={() => handleDelete(video)}
                        onUpdateField={handleUpdateField}
                    />
                ))}
            </div>

            {playingVideo && (
                <VideoPlayer videoUrl={playingVideo.url} onClose={closePlayer} />
            )}
        </section>
    );
};

VideoNews.propTypes = {
    initialVideos: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            thumb: PropTypes.string,
            title: PropTypes.string.isRequired,
            duration: PropTypes.string,
            url: PropTypes.string,
            category: PropTypes.string,
        })
    ),
    onDeleteVideo: PropTypes.func,
    onUpdateVideo: PropTypes.func,
};

export default VideoNews;
