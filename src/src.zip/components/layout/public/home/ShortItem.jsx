// src/components/layout/public/home/ShortItem.jsx
import React, { useRef, useContext, useCallback } from "react";
import PropTypes from "prop-types";
import "../../../../assets/css/ShortSection.css";
import { AdminModeContext } from "../PublicLayout";
import { useEditable } from "../../../../hooks/useEditable";

/**
 * ShortItem: muestra un short con miniatura, duración, título y vistas.
 * En modo admin permite editar cada campo o eliminar.
 * Props:
 *   - short: { id, img, title, duration, views }
 *   - isAdminMode: boolean (true si es admin y editor)
 *   - onUpdateField: función (shortId, updatedFields)
 *   - onDelete: función para eliminar el short
 *   - onPlay: función para reproducir el short (solo en modo usuario)
 */
const ShortItem = ({ short, isAdminMode, onUpdateField, onDelete, onPlay }) => {
    const { id, img, title, duration, views } = short;
    const { isAdminMode: admin } = useContext(AdminModeContext);

    // Refs para partes editables
    const imgRef = useRef();
    const titleRef = useRef();
    const durationRef = useRef();
    const viewsRef = useRef();

    // Handler genérico memoizado para actualizaciones
    const handleSave = useCallback(
        (newValues, meta) => {
            const updated = {};
            switch (meta.field) {
                case "img":
                    updated.img = newValues.src;
                    break;
                case "title":
                    updated.title = newValues.html;
                    break;
                case "duration":
                    updated.duration = newValues.text;
                    break;
                case "views":
                    updated.views = newValues.text;
                    break;
                default:
                    return;
            }
            onUpdateField(id, updated);
        },
        [id, onUpdateField]
    );

    // Registro de campos editables
    useEditable(
        imgRef,
        "image",
        () => ({ src: img, alt: title }),
        () => ({ presets: ["short", "clip", "video", "snippet"] }),
        handleSave,
        { field: "img" }
    );
    useEditable(
        titleRef,
        "text",
        () => ({ html: title }),
        () => ({}),
        handleSave,
        { field: "title" }
    );
    useEditable(
        durationRef,
        "duration",
        () => ({ text: duration }),
        () => ({ label: "Duración:" }),
        handleSave,
        { field: "duration" }
    );
    useEditable(
        viewsRef,
        "text",
        () => ({ text: String(views) }),
        () => ({ label: "Vistas:" }),
        handleSave,
        { field: "views" }
    );

    // Click handlers
    const onCardClick = () => {
        if (!admin) onPlay();
    };
    const onImgClick = (e) => {
        if (!admin) onPlay();
    };

    return (
        <div
            className={`short${admin ? " editable-container" : ""}`}
            onClick={onCardClick}
            role={!admin ? "button" : undefined}
            tabIndex={!admin ? 0 : undefined}
        >
            {admin && (
                <button
                    className="delete-item-btn"
                    onClick={(e) => {
                        e.stopPropagation();
                        onDelete();
                    }}
                    aria-label={`Eliminar short "${title}"`}
                >
                    🗑
                </button>
            )}
            <div className="short-thumbnail">
                <div ref={imgRef} className={admin ? "editable" : ""}>
                    <img
                        src={img}
                        alt={title}
                        onClick={onImgClick}
                        aria-label={admin ? "Editar imagen" : undefined}
                    />
                </div>
                <div
                    ref={durationRef}
                    className={`short-duration${admin ? " editable" : ""}`}
                    role={admin ? "button" : undefined}
                    tabIndex={admin ? 0 : undefined}
                >
                    {duration}
                </div>
                <div className="short-play-button">
                    <i className="fas fa-play" />
                </div>
            </div>
            <div className="short-info">
                <h4
                    ref={titleRef}
                    className={admin ? "editable" : ""}
                    role={admin ? "button" : undefined}
                    tabIndex={admin ? 0 : undefined}
                >
                    {title}
                </h4>
                <span
                    ref={viewsRef}
                    className={`short-views${admin ? " editable" : ""}`}
                    role={admin ? "button" : undefined}
                    tabIndex={admin ? 0 : undefined}
                >
                    {views}
                </span>
            </div>
        </div>
    );
};

ShortItem.propTypes = {
    short: PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
        img: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        duration: PropTypes.string.isRequired,
        views: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired
    }).isRequired,
    isAdminMode: PropTypes.bool,
    onUpdateField: PropTypes.func,
    onDelete: PropTypes.func,
    onPlay: PropTypes.func
};

export default ShortItem;
