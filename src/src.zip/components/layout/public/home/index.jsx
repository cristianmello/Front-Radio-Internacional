// src/components/layout/public/home/index.jsx
import React, { useState, useEffect, useContext } from "react";

import BreakingNews from "./BreakingNews";
import AdSection from "./AdSection";
import TrendingNews from "./TrendingNews";
import MainContent from "./MainContent";
import VideoNews from "./VideoNews";
import ShortsSection from "./ShortSection";
import WorldNews from "./WorldNews";
import MosaicNews from "./MosaicNews";

import EditorToolbar from "../../../editing/EditorToolbar";
import NewsModal from "../../../editing/NewsModal";
import EditModal from "../../../editing/EditModal";
import SectionModal from "../../../editing/SectionModal";
import useAuth from "../../../../hooks/UseAuth";
import { AdminModeContext } from "../PublicLayout";
const HomePage = () => {

    const { auth } = useAuth();
    const isAdmin = ["editor", "admin", "superadmin"].includes(auth?.role?.role_name);

    const [showNewsModal, setShowNewsModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showSectionModal, setShowSectionModal] = useState(false);
    const [editFields, setEditFields] = useState([]);

    // --- Estado de categoría ---
    const [selectedCategory, setSelectedCategory] = useState("inicio");

    // opcional: título dinámico
    const [sectionTitle, setSectionTitle] = useState("Últimas Noticias");

    useEffect(() => {
        if (selectedCategory === "inicio") {
            setSectionTitle("Últimas Noticias");
        } else {
            // convierte "politica" → "Política", etc.
            setSectionTitle(selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1));
        }
    }, [selectedCategory]);

    // Accedemos al contexto global de admin-mode
    const { isAdminMode, setIsAdminMode } = useContext(AdminModeContext);

    const handleSaveAll = () => {
        console.log("Guardando todos los cambios en el servidor...");
    };
    const handleDiscardAll = () => {
        console.log("Descartando todos los cambios");
    };
    const handleAddSection = () => setShowSectionModal(true);
    const handleAddNews = data => {/*…*/ setShowNewsModal(false); };
    const handleEdit = data => {/*…*/ setShowEditModal(false); };
    const handleCreateSection = data => {
        console.log("Creando sección nueva:", title, type);
        setShowSectionModal(false);
    };

    return (
        <main>
            <div className="container">

                {isAdmin && (
                    <>
                        {/* Botón global ya en PublicLayout, aquí sólo abrimos modales */}
                        <EditorToolbar
                            onSave={handleSaveAll}
                            onDiscard={handleDiscardAll}
                            onAddSection={handleAddSection}
                        />

                        <NewsModal
                            isOpen={showNewsModal}
                            onClose={() => setShowNewsModal(false)}
                            onSubmit={handleAddNews}
                        />
                        <EditModal
                            isOpen={showEditModal}
                            onClose={() => setShowEditModal(false)}
                            onSubmit={handleEdit}
                            fields={editFields}
                        />
                        <SectionModal
                            isOpen={showSectionModal}
                            onClose={() => setShowSectionModal(false)}
                            onCreate={handleCreateSection}
                        />
                    </>
                )}

                {/* Navegación por categorías */}
                <nav className="category-nav">
                    <ul className="nav-list">
                        {[
                            { key: "inicio", label: "Inicio" },
                            { key: "politica", label: "Política" },
                            { key: "economia", label: "Economía" },
                            { key: "tecnologia", label: "Tecnología" },
                            { key: "deportes", label: "Deportes" },
                            { key: "entretenimiento", label: "Entretenimiento" },
                            { key: "ciencia", label: "Ciencia" },
                        ].map(cat => (
                            <li
                                key={cat.key}
                                className={selectedCategory === cat.key ? "active" : ""}
                                onClick={() => setSelectedCategory(cat.key)}
                            >
                                {cat.label}
                            </li>
                        ))}
                    </ul>
                </nav>

                {/* 1) SECTION: Últimas Noticias / Breaking News */}
                {selectedCategory === "inicio" && <BreakingNews />}

                {/* 2) SECTION: Anuncio grande */}
                <AdSection />

                {/* 3) SECTION: Tendencias / Trending News */}
                {selectedCategory === "inicio" && <TrendingNews />}

                {/* 4) LAYOUT PRINCIPAL: Destacados + Sidebar */}
                <MainContent />

                {/* 5) SECTION: En Video / Video News */}
                {selectedCategory === "inicio" && <VideoNews />}

                {/* 6) SECTION: Shorts */}
                {selectedCategory === "inicio" && <ShortsSection />}

                {/* 7) World News (Noticias del Mundo) */}
                {selectedCategory === "inicio" && <WorldNews />}

                {/* 8) SECTION: Mosaic / Panorama Noticioso */}
                {selectedCategory === "inicio" && <MosaicNews />}

                {/* 9) ÚLTIMO AD antes del footer */}
                <AdSection />
            </div>
        </main>
    );
};

export default HomePage;
