import React, { useState, useEffect } from "react";
import "../../../assets/css/AuthModal.css";

const AuthModal = ({ isOpen, onClose, onLogin, onRegister, onRecover }) => {
    // Estado de pestaña activa: "login", "register" o "recovery"
    const [activeTab, setActiveTab] = useState("login");

    // Cuando se abre el modal, garantizamos que arranque en "login"
    useEffect(() => {
        if (isOpen) {
            setActiveTab("login");
        }
    }, [isOpen]);

    if (!isOpen) return null;

    return (
        <div id="auth-modal" className="auth-modal open">
            <div className="auth-container">
                <button className="close-auth-button" onClick={onClose}>
                    &times;
                </button>

                {/* ===== PESTAÑAS ===== */}
                <div className="auth-tabs">
                    <button
                        className={`auth-tab ${activeTab === "login" ? "active" : ""}`}
                        onClick={() => setActiveTab("login")}
                    >
                        Iniciar Sesión
                    </button>
                    <button
                        className={`auth-tab ${activeTab === "register" ? "active" : ""}`}
                        onClick={() => setActiveTab("register")}
                    >
                        Registrarse
                    </button>
                    <button
                        className={`auth-tab ${activeTab === "recovery" ? "active" : ""}`}
                        onClick={() => setActiveTab("recovery")}
                    >
                        Recuperar Contraseña
                    </button>
                </div>

                {/* ===== FORMULARIOS ===== */}
                <div className="auth-form-container">
                    {/* --- LOGIN --- */}
                    <form
                        id="login-form"
                        className={`auth-form ${activeTab === "login" ? "active" : ""}`}
                        onSubmit={(e) => {
                            e.preventDefault();
                            const email = e.target["login-email"].value;
                            const password = e.target["login-password"].value;
                            onLogin({ email, password });
                        }}
                    >
                        <h3>Iniciar Sesión</h3>
                        <div className="form-group">
                            <label htmlFor="login-email">Correo Electrónico</label>
                            <input type="email" id="login-email" required />
                        </div>
                        <div className="form-group">
                            <label htmlFor="login-password">Contraseña</label>
                            <input type="password" id="login-password" required />
                        </div>
                        <div className="form-options">
                            <label>
                                <input type="checkbox" /> Recordarme
                            </label>
                        </div>
                        <button type="submit" className="auth-submit">
                            Iniciar Sesión
                        </button>
                    </form>

                    {/* --- REGISTER --- */}
                    <form
                        id="register-form"
                        className={`auth-form ${activeTab === "register" ? "active" : ""
                            }`}
                        onSubmit={(e) => {
                            e.preventDefault();
                            const name = e.target["register-name"].value;
                            const email = e.target["register-email"].value;
                            const password = e.target["register-password"].value;
                            const confirm = e.target["register-confirm"].value;
                            onRegister({ name, email, password, confirm });
                        }}
                    >
                        <h3>Crear Cuenta</h3>
                        <div className="form-group">
                            <label htmlFor="register-name">Nombre Completo</label>
                            <input type="text" id="register-name" required />
                        </div>
                        <div className="form-group">
                            <label htmlFor="register-email">Correo Electrónico</label>
                            <input type="email" id="register-email" required />
                        </div>
                        <div className="form-group">
                            <label htmlFor="register-password">Contraseña</label>
                            <input type="password" id="register-password" required />
                        </div>
                        <div className="form-group">
                            <label htmlFor="register-confirm">Confirmar Contraseña</label>
                            <input type="password" id="register-confirm" required />
                        </div>
                        <div className="form-options">
                            <label>
                                <input type="checkbox" required /> Acepto los términos y
                                condiciones
                            </label>
                        </div>
                        <button type="submit" className="auth-submit">
                            Registrarse
                        </button>
                    </form>

                    {/* --- RECOVER --- */}
                    <form
                        id="recovery-form"
                        className={`auth-form ${activeTab === "recovery" ? "active" : ""
                            }`}
                        onSubmit={(e) => {
                            e.preventDefault();
                            const email = e.target["recovery-email"].value;
                            onRecover({ email });
                        }}
                    >
                        <h3>Recuperar Contraseña</h3>
                        <p>
                            Ingresa tu correo electrónico y te enviaremos un enlace para
                            restablecer tu contraseña.
                        </p>
                        <div className="form-group">
                            <label htmlFor="recovery-email">Correo Electrónico</label>
                            <input type="email" id="recovery-email" required />
                        </div>
                        <button type="submit" className="auth-submit">
                            Enviar Enlace
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default AuthModal;
