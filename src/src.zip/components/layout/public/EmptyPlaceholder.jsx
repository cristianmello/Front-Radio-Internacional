// src/components/common/EmptyPlaceholder.jsx
const EmptyPlaceholder = ({ condition, message }) => {
    if (!condition) return null;

    return (
        <div
            className="empty-placeholder"
            style={{
                padding: '20px',
                textAlign: 'center',
                color: 'var(--text-lighter)',
                fontStyle: 'italic',
                border: '1px dashed var(--border-color)',
                borderRadius: '8px',
                margin: '15px 0',
            }}
        >
            {message}
        </div>
    );
};

export default EmptyPlaceholder;
