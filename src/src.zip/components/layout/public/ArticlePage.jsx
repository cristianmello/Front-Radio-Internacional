// src/components/layout/public/ArticlePage.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../../assets/css/ArticlePage.css";
import AuthModal from "./AuthModal";
import EditorToolbar from "../../editing/EditorToolbar";
import EditModal from "../../editing/EditModal";
import SectionModal from "../../editing/SectionModal";
import NewsModal from "../../editing/NewsModal";
import useArticleData from "../../../hooks/UseArticleData";

const ArticlePage = () => {
    const navigate = useNavigate();
    const { article, relatedNews, loading } = useArticleData();

    const [editorMode, setEditorMode] = useState(false);
    const [isEditOpen, setEditOpen] = useState(false);
    const [isSectionOpen, setSectionOpen] = useState(false);
    const [isNewsOpen, setNewsOpen] = useState(false);
    const [isAuthOpen, setIsAuthOpen] = useState(false);

    // Handlers para toolbar y modales
    const handleSave = () => { console.log("Guardar cambios de artículo", article); setEditorMode(false); };
    const handleDiscard = () => { console.log("Descartar cambios"); setEditorMode(false); };
    const handleAddSection = () => setSectionOpen(true);
    const handleAddNews = () => setNewsOpen(true);
    const handleEditSubmit = data => { console.log("Campos editados:", data); setEditOpen(false); };

    // Compartir en redes
    const shareUrl = encodeURIComponent(window.location.href);
    const shareTitle = encodeURIComponent(article?.article_title || "");
    const share = {
        facebook: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`, "_blank"),
        twitter: () => window.open(`https://twitter.com/intent/tweet?url=${shareUrl}&text=${shareTitle}`, "_blank"),
        whatsapp: () => window.open(`https://api.whatsapp.com/send?text=${shareTitle}%20${shareUrl}`, "_blank"),
        telegram: () => window.open(`https://t.me/share/url?url=${shareUrl}&text=${shareTitle}`, "_blank"),
        email: () => (window.location.href = `mailto:?subject=${shareTitle}&body=Te%20comparto%20este%20art%C3%ADculo:%20${shareUrl}`)
    };

    if (loading) return <p>Cargando artículo…</p>;
    if (!article) return <p>Artículo no encontrado</p>;

    return (
        <div className="article-page">
            {/* Toggle Modo Editor */}
            <button className="admin-btn" onClick={() => setEditorMode(m => !m)}>
                <i className="fas fa-cog" /> {editorMode ? "Salir Modo Editor" : "Modo Editor"}
            </button>

            {editorMode && (
                <EditorToolbar
                    onSave={handleSave}
                    onDiscard={handleDiscard}
                    onAddSection={handleAddSection}
                />
            )}

            {/* Modales de edición */}
            <EditModal
                isOpen={isEditOpen}
                onClose={() => setEditOpen(false)}
                onSubmit={handleEditSubmit}
                fields={[
                    { label: "Título", id: "title", type: "text", value: article.article_title },
                    { label: "Contenido", id: "content", type: "text", value: article.article_content }
                ]}
            />
            <SectionModal
                isOpen={isSectionOpen}
                onClose={() => setSectionOpen(false)}
                onCreate={data => { console.log("Sección creada:", data); setSectionOpen(false); }}
            />
            <NewsModal
                isOpen={isNewsOpen}
                onClose={() => setNewsOpen(false)}
                onSubmit={data => { console.log("Noticia agregada:", data); setNewsOpen(false); }}
            />
            <AuthModal
                isOpen={isAuthOpen}
                onClose={() => setIsAuthOpen(false)}
                onLogin={d => { console.log("Login:", d); setIsAuthOpen(false); }}
                onRegister={d => { console.log("Register:", d); setIsAuthOpen(false); }}
                onRecover={d => { console.log("Recover:", d); setIsAuthOpen(false); }}
            />

            <main className="article-main">
                <div className="container">
                    <div className="article-layout">
                        {/* Artículo principal */}
                        <article className="article-content">
                            <div className="breadcrumbs">
                                <Link to="/">Inicio</Link> &gt; <span>{article.category.category_name}</span>
                            </div>

                            <div className="article-meta-top">
                                <span className="article-category-label">{article.category.category_name}</span>
                                <span className="article-date">
                                    {new Date(article.article_published_at || article.created_at).toLocaleString()}
                                </span>
                            </div>

                            <h1 className="article-title">{article.article_title}</h1>

                            <div className="article-author">
                                <img
                                    src={article.article_image_url || "https://source.unsplash.com/random/50x50/?person"}
                                    alt="Autor"
                                    className="author-image"
                                />
                                <div className="author-info">
                                    <span className="author-name">
                                        {article.author.user_name} {article.author.user_lastname}
                                    </span>
                                </div>
                            </div>

                            {article.article_image_url && (
                                <div className="article-featured-image">
                                    <img src={article.article_image_url} alt="Destacada" />
                                    <div className="image-caption">Pie de foto editables</div>
                                </div>
                            )}

                            <div className="social-share-sticky">
                                <button onClick={share.facebook}><i className="fab fa-facebook-f" /></button>
                                <button onClick={share.twitter}><i className="fab fa-twitter" /></button>
                                <button onClick={share.whatsapp}><i className="fab fa-whatsapp" /></button>
                                <button onClick={share.telegram}><i className="fab fa-telegram-plane" /></button>
                                <button onClick={share.email}><i className="fas fa-envelope" /></button>
                            </div>

                            <div
                                className="article-body"
                                dangerouslySetInnerHTML={{ __html: article.article_content }}
                            />

                            {article.tags && (
                                <div className="article-tags">
                                    <span className="tag-label">Temas:</span>
                                    {article.tags.map(tag => (
                                        <Link key={tag} to={`/tags/${tag}`} className="article-tag">
                                            {tag}
                                        </Link>
                                    ))}
                                </div>
                            )}
                        </article>

                        {/* Sidebar Noticias Relacionadas */}
                        <aside className="article-sidebar">
                            <div className="widget related-news">
                                <h3>Noticias Relacionadas</h3>
                                {relatedNews.length > 0 ? (
                                    relatedNews.map(rel => (
                                        <div
                                            key={rel.article_code}
                                            className="related-news-item"
                                            onClick={() => navigate(`/articles/${rel.article_code}`)}
                                        >
                                            <img src={rel.article_image_url} alt={rel.article_title} />
                                            <div className="related-news-info">
                                                <h4>{rel.article_title}</h4>
                                                <span className="related-date">
                                                    {new Date(rel.article_published_at || rel.created_at).toLocaleDateString()}
                                                </span>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <p>No hay noticias relacionadas.</p>
                                )}
                            </div>
                        </aside>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default ArticlePage;
