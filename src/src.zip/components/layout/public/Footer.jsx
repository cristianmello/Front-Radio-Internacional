import React from "react";
import { Link } from "react-router-dom"; // usaremos <Link> para rutas internas
import "../../../assets/css/Footer.css";

const Footer = () => {
  return (
    <footer>
      <div className="container">
        <div className="footer-content">
          {/* Logo y descripción */}
          <div className="footer-logo">
            <h2>InfoMundo</h2>
            <p>Tu portal de noticias confiable</p>
          </div>

          {/* Bloque de enlaces */}
          <div className="footer-links">
            {/* ------ CATEGORÍAS ------ */}
            <div className="footer-section">
              <h3>Categorías</h3>
              <ul>
                <li>
                  <Link to="/categoria/politica">Política</Link>
                </li>
                <li>
                  <Link to="/categoria/economia">Economía</Link>
                </li>
                <li>
                  <Link to="/categoria/tecnologia">Tecnología</Link>
                </li>
                <li>
                  <Link to="/categoria/deportes">Deportes</Link>
                </li>
                <li>
                  <Link to="/categoria/entretenimiento">Entretenimiento</Link>
                </li>
              </ul>
            </div>

            {/* ------ COMPAÑÍA ------ */}
            <div className="footer-section">
              <h3>Compañía</h3>
              <ul>
                <li>
                  <Link to="/about">Sobre nosotros</Link>
                </li>
                <li>
                  <Link to="/team">Equipo editorial</Link>
                </li>
                <li>
                  <Link to="/careers">Trabaja con nosotros</Link>
                </li>
                <li>
                  <Link to="/contact">Contacto</Link>
                </li>
              </ul>
            </div>

            {/* ------ LEGAL ------ */}
            <div className="footer-section">
              <h3>Legal</h3>
              <ul>
                <li>
                  <Link to="/terms">Términos y condiciones</Link>
                </li>
                <li>
                  <Link to="/privacy">Política de privacidad</Link>
                </li>
                <li>
                  <Link to="/cookies">Política de cookies</Link>
                </li>
              </ul>
            </div>
          </div>

          {/* ------ REDES SOCIALES ------ */}
          <div className="footer-social">
            <h3>Síguenos</h3>
            <div className="social-icons">
              <a href="https://facebook.com" target="_blank" rel="noreferrer">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer">
                <i className="fab fa-twitter"></i>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer">
                <i className="fab fa-youtube"></i>
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
              >
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
        </div>

        {/* Pie de página inferior */}
        <div className="footer-bottom">
          <p>© 2023 InfoMundo - Todos los derechos reservados</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
