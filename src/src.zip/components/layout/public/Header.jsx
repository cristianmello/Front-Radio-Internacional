// src/components/layout/public/Header.jsx
import React, { useEffect, useState } from "react";
import { NavLink, Link } from "react-router-dom";
import useAuth from "../../../hooks/UseAuth";
import logo from "../../../assets/img/logos-1.png";
import "../../../assets/css/Header.css";

const Header = ({ onOpenAuth }) => {
  const { auth } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen((prev) => !prev);
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768 && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [mobileMenuOpen]);

  return (
    <header>
      <div className="header-top">
        <div className="container">
          {/* Logo */}
          <div className="logo">
            <Link to="/">
              <h1>InfoMundo</h1>
            </Link>
          </div>

          {/* Autenticación */}
          <div className="user-auth">
            {!auth?.id ? (
              // Ahora en lugar de <Link to="/login">, debo llamar a onOpenAuth()
              <button
                className="auth-btn login-btn"
                onClick={onOpenAuth}
                type="button"
              >
                Ingresar
              </button>
            ) : (
              <>
                <Link to="/profile">
                  <button className="auth-btn">Perfil</button>
                </Link>
                <Link to="/logout">
                  <button className="auth-btn">Cerrar sesión</button>
                </Link>
              </>
            )}
          </div>

          {/* Toggle menú móvil */}
          <div className="mobile-menu-toggle" onClick={toggleMobileMenu}>
            <i className="fas fa-bars"></i>
          </div>
        </div>
      </div>

      <nav className="main-nav">
        <div className="container">
          <ul className={`nav-list ${mobileMenuOpen ? "open" : ""}`}>
            <li>
              <NavLink to="/" className={({ isActive }) => (isActive ? "active" : "")}>
                Inicio
              </NavLink>
            </li>
            <li>
              <NavLink to="/categoria/politica" className={({ isActive }) => (isActive ? "active" : "")}>
                Política
              </NavLink>
            </li>
            <li>
              <NavLink to="/categoria/economia" className={({ isActive }) => (isActive ? "active" : "")}>
                Economía
              </NavLink>
            </li>
            <li>
              <NavLink to="/categoria/tecnologia" className={({ isActive }) => (isActive ? "active" : "")}>
                Tecnología
              </NavLink>
            </li>
            <li>
              <NavLink to="/categoria/deportes" className={({ isActive }) => (isActive ? "active" : "")}>
                Deportes
              </NavLink>
            </li>
            <li>
              <NavLink to="/categoria/entretenimiento" className={({ isActive }) => (isActive ? "active" : "")}>
                Entretenimiento
              </NavLink>
            </li>
            <li>
              <NavLink to="/categoria/ciencia" className={({ isActive }) => (isActive ? "active" : "")}>
                Ciencia
              </NavLink>
            </li>
            {isAdmin && (
              <li className="gallery-link">
                <NavLink to="/admin/gallery">
                  <i className="fas fa-images"></i> Galería
                </NavLink>
              </li>
            )}

          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;