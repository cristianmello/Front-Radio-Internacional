// src/components/layout/public/gallery/GalleryPage.jsx
import React, { useState, useEffect } from "react";
import "../../../assets/css/Gallery.css";

import GalleryFilters from "./GalleryFilters";
import GalleryActions from "./GalleryActions";
import GalleryStats from "./GalleryStats";
import GalleryGrid from "./GalleryGrid";
import EmptyGallery from "./EmptyGallery";
import CreateEditNewsModal from "./CreateEditNewsModal";
import PreviewModal from "./PreviewModal";
import DeleteModal from "./DeleteModal";

const initialNews = []; // aquí podrías cargar de tu API o localStorage

const GalleryPage = () => {
    const [newsList, setNewsList] = useState(initialNews);
    const [filter, setFilter] = useState("all");
    const [editorMode, setEditorMode] = useState(false);
    const [modalMode, setModalMode] = useState(null); // "create"|"edit"|"preview"|"delete"
    const [currentNews, setCurrentNews] = useState(null);

    // Filtrado
    const filteredNews = filter === "all"
        ? newsList
        : newsList.filter(n => n.category === filter);

    // Estadísticas
    const totalNews = newsList.length;
    const categoriesCount = new Set(newsList.map(n => n.category)).size;
    const recentlyUsed = newsList.filter(n => n.lastUsed && (Date.now() - n.lastUsed) < 7 * 24 * 3600_000).length;

    // Handlers
    const handleFilterChange = (newFilter) => setFilter(newFilter);
    const handleCreateNews = () => { setCurrentNews(null); setModalMode("create"); };
    const handleEditNews = (news) => { setCurrentNews(news); setModalMode("edit"); };
    const handlePreviewNews = (news) => { setCurrentNews(news); setModalMode("preview"); };
    const handleDeleteNews = (news) => { setCurrentNews(news); setModalMode("delete"); };

    const handleSaveNews = (data) => {
        if (modalMode === "edit") {
            setNewsList(list => list.map(n => n.id === data.id ? data : n));
        } else {
            setNewsList(list => [...list, { ...data, id: Date.now() }]);
        }
        setModalMode(null);
    };

    const handleConfirmDelete = () => {
        setNewsList(list => list.filter(n => n.id !== currentNews.id));
        setModalMode(null);
    };

    return (
        <>
            <div className="gallery-page">
                <main className="gallery-main">
                    <div className="container">

                        {/* Toggle Modo Editor */}
                        <button
                            className="admin-btn"
                            onClick={() => setEditorMode(!editorMode)}
                        >
                            <i className="fas fa-cog"></i>{" "}
                            {editorMode ? "Salir Modo Editor" : "Modo Editor"}
                        </button>

                        <div className="gallery-controls">

                            <GalleryFilters
                                filter={filter}
                                onChange={handleFilterChange}
                            />

                            <GalleryActions
                                onCreate={handleCreateNews}
                                onImport={() => { }}
                                onExport={() => { }}
                            />
                        </div>

                        <GalleryStats
                            totalNews={totalNews}
                            categoriesCount={categoriesCount}
                            recentlyUsed={recentlyUsed}
                        />

                        {filteredNews.length > 0
                            ? <GalleryGrid
                                newsList={filteredNews}
                                editorMode={editorMode}
                                onEdit={handleEditNews}
                                onPreview={handlePreviewNews}
                                onDelete={handleDeleteNews}
                            />
                            : <EmptyGallery onCreate={handleCreateNews} />
                        }
                    </div>
                </main>
            </div>

            {/* Modales */}
            {modalMode === "create" || modalMode === "edit" ? (
                <CreateEditNewsModal
                    isOpen
                    news={currentNews}
                    onClose={() => setModalMode(null)}
                    onSave={handleSaveNews}
                />
            ) : null}

            {modalMode === "preview" && (
                <PreviewModal
                    news={currentNews}
                    onClose={() => setModalMode(null)}
                    onEdit={() => { setModalMode("edit"); }}
                    onUse={() => {/* integrar en el home */ }}
                />
            )}

            {modalMode === "delete" && (
                <DeleteModal
                    onClose={() => setModalMode(null)}
                    onConfirm={handleConfirmDelete}
                />
            )}
        </>
    );
};

export default GalleryPage;
