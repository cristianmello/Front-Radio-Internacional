// src/components/layout/public/gallery/DeleteModal.jsx
import React from "react";

const DeleteModal = ({ onClose, onConfirm }) => (
    <div className="gallery-modal open">
        <div className="gallery-modal-content delete-modal">
            <div className="modal-header">
                <h3>Confirmar Eliminación</h3>
                <button className="close-modal" onClick={onClose}><i className="fas fa-times"></i></button>
            </div>
            <div className="delete-content">
                <div className="delete-icon"><i className="fas fa-exclamation-triangle"></i></div>
                <p>¿Estás seguro de que quieres eliminar esta noticia?</p>
                <p className="delete-warning">Esta acción no se puede deshacer.</p>
            </div>
            <div className="delete-actions">
                <button className="btn-secondary" onClick={onClose}>Cancelar</button>
                <button className="btn-danger" onClick={onConfirm}><i className="fas fa-trash"></i> Eliminar</button>
            </div>
        </div>
    </div>
);

export default DeleteModal;
