// src/components/layout/public/gallery/GalleryGrid.jsx
import React from "react";

const GalleryGrid = ({ newsList, editorMode, onEdit, onPreview, onDelete }) => (
    <div className="gallery-grid">
        {newsList.map(item => (
            <div className="gallery-item" key={item.id}>
                <img src={item.image} alt={item.title} />
                <h4>{item.title}</h4>
                <p>{item.excerpt}</p>
                <div className="gallery-item-actions">
                    <button onClick={() => onPreview(item)}>🔍</button>
                    {editorMode && <button onClick={() => onEdit(item)}>✏️</button>}
                    {editorMode && <button onClick={() => onDelete(item)}>🗑️</button>}
                </div>
            </div>
        ))}
    </div>
);

export default GalleryGrid;
