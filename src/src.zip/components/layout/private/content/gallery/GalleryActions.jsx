// src/components/layout/public/gallery/GalleryActions.jsx
import React from "react";

const GalleryActions = ({ onCreate, onImport, onExport }) => (
    <div className="gallery-actions">
        <button className="gallery-btn create-news-btn" onClick={onCreate}>
            <i className="fas fa-plus"></i> Crear Noticia
        </button>
        <button className="gallery-btn import-btn" onClick={onImport}>
            <i className="fas fa-upload"></i> Importar
        </button>
        <button className="gallery-btn export-btn" onClick={onExport}>
            <i className="fas fa-download"></i> Exportar Todo
        </button>
    </div>
);

export default GalleryActions;
