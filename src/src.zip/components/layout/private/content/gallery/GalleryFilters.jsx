// src/components/layout/public/gallery/GalleryFilters.jsx
import React from "react";

const categories = ["all", "política", "economía", "tecnología", "deportes", "entretenimiento", "ciencia"];

const GalleryFilters = ({ filter, onChange }) => (
    <div className="gallery-filters">
        {categories.map(cat => (
            <button
                key={cat}
                className={`filter-btn ${filter === cat ? "active" : ""}`}
                onClick={() => onChange(cat)}
            >
                {cat === "all" ? "Todas" : cat.charAt(0).toUpperCase() + cat.slice(1)}
            </button>
        ))}
    </div>
);

export default GalleryFilters;
