// src/components/layout/public/gallery/CreateEditNewsModal.jsx
import React, { useState, useEffect } from "react";

const CreateEditNewsModal = ({ isOpen, news, onClose, onSave }) => {
    const [form, setForm] = useState({});

    useEffect(() => {
        if (isOpen) {
            setForm(news || {
                title: "", category: "", author: "",
                date: "", image: "", excerpt: "",
                readTime: "", tags: "", content: ""
            });
        }
    }, [isOpen, news]);

    if (!isOpen) return null;

    const handleChange = e => {
        const { id, value } = e.target;
        setForm(f => ({ ...f, [id]: value }));
    };

    const handleSubmit = e => {
        e.preventDefault();
        onSave(form);
    };

    return (
        <div className="gallery-modal open">
            <div className="gallery-modal-content">
                <div className="modal-header">
                    <h3>{news ? "Editar Noticia" : "Crear Nueva Noticia"}</h3>
                    <button className="close-modal" onClick={onClose}><i className="fas fa-times"></i></button>
                </div>
                <form className="news-form" onSubmit={handleSubmit}>
                    {[
                        { label: "Título *", id: "title", type: "text", required: true },
                        { label: "Categoría *", id: "category", type: "select", required: true, options: ["política", "economía", "tecnología", "deportes", "entretenimiento", "ciencia", "salud", "internacional", "cultura", "medio ambiente"] },
                        { label: "Autor *", id: "author", type: "text", required: true },
                        { label: "Fecha", id: "date", type: "text" },
                        { label: "URL de Imagen", id: "image", type: "text" },
                        { label: "Extracto *", id: "excerpt", type: "textarea", required: true },
                        { label: "Tiempo Lectura", id: "readTime", type: "text" },
                        { label: "Etiquetas", id: "tags", type: "text" },
                        { label: "Contenido Completo", id: "content", type: "textarea" },
                    ].map(field => (
                        <div className="form-group" key={field.id}>
                            <label htmlFor={field.id}>{field.label}</label>
                            {field.type === "textarea" ? (
                                <textarea id={field.id} value={form[field.id] || ""} onChange={handleChange} rows={3} required={field.required} />
                            ) : field.type === "select" ? (
                                <select id={field.id} value={form[field.id] || ""} onChange={handleChange} required={field.required}>
                                    <option value="">Seleccionar categoría</option>
                                    {field.options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                </select>
                            ) : (
                                <input
                                    type={field.type}
                                    id={field.id}
                                    value={form[field.id] || ""}
                                    onChange={handleChange}
                                    placeholder={field.placeholder || ""}
                                    required={field.required}
                                />
                            )}
                        </div>
                    ))}
                    <div className="form-actions">
                        <button type="button" className="btn-secondary" onClick={onClose}>Cancelar</button>
                        <button type="submit" className="btn-primary"><i className="fas fa-save"></i> Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateEditNewsModal;
