// src/components/layout/public/gallery/GalleryStats.jsx
import React from "react";

const GalleryStats = ({ totalNews, categoriesCount, recentlyUsed }) => (
    <div className="gallery-stats">
        <div className="stat-item">
            <span className="stat-number">{totalNews}</span>
            <span className="stat-label">Noticias Guardadas</span>
        </div>
        <div className="stat-item">
            <span className="stat-number">{categoriesCount}</span>
            <span className="stat-label">Categorías</span>
        </div>
        <div className="stat-item">
            <span className="stat-number">{recentlyUsed}</span>
            <span className="stat-label">Usadas Recientemente</span>
        </div>
    </div>
);

export default GalleryStats;
