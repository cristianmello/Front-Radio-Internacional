// src/components/layout/public/gallery/PreviewModal.jsx
import React from "react";

const PreviewModal = ({ news, onClose, onEdit, onUse }) => {
    if (!news) return null;
    return (
        <div className="gallery-modal open">
            <div className="gallery-modal-content preview-modal">
                <div className="modal-header">
                    <h3>Vista Previa</h3>
                    <button className="close-modal" onClick={onClose}><i className="fas fa-times"></i></button>
                </div>
                <div className="preview-content">
                    <h2>{news.title}</h2>
                    <p><em>{news.category} • {news.author} • {news.date}</em></p>
                    <img src={news.image} alt={news.title} />
                    <p>{news.excerpt}</p>
                </div>
                <div className="preview-actions">
                    <button className="btn-secondary" onClick={onEdit}><i className="fas fa-edit"></i> Editar</button>
                    <button className="btn-primary" onClick={() => onUse(news)}><i className="fas fa-check"></i> Usar en Sitio</button>
                </div>
            </div>
        </div>
    );
};

export default PreviewModal;
