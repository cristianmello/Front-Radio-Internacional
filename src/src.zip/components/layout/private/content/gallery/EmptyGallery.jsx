// src/components/layout/public/gallery/EmptyGallery.jsx
import React from "react";

const EmptyGallery = ({ onCreate }) => (
    <div className="empty-gallery">
        <div className="empty-icon"><i className="fas fa-newspaper"></i></div>
        <h3>Tu galería está vacía</h3>
        <p>Comienza creando tu primera noticia para guardarla en la galería</p>
        <button className="gallery-btn create-first-news" onClick={onCreate}>
            <i className="fas fa-plus"></i> Crear Primera Noticia
        </button>
    </div>
);

export default EmptyGallery;
