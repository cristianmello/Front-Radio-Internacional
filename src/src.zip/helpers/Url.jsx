export const Url = {
    url: "http://192.168.1.14:5173/api/"
};
